import 'package:animal_kart_demo2/profile/providers/profile_provider.dart';
import 'package:animal_kart_demo2/refer_earn/widgets/refer_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ReferEarnScreen extends ConsumerStatefulWidget {
  const ReferEarnScreen({super.key});

  @override
  ConsumerState<ReferEarnScreen> createState() => _ReferEarnScreenState();
}

class _ReferEarnScreenState extends ConsumerState<ReferEarnScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(profileProvider.notifier).fetchCurrentUser();
    });
  }

  @override
  Widget build(BuildContext context) {
    final profileState = ref.watch(profileProvider);
    final referralCode = profileState.currentUser?.referralCode ?? '';
    final userRole = profileState.currentUser?.role ?? '';

    final isAbleToRefer = profileState.currentUser?.isAbleToRefer ?? false;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F4F4),
      body: CustomScrollView(
        slivers: [
          const ReferSliverAppBar(),
          SliverToBoxAdapter(
            child: Column(
              children: [
                ReferWhatsAppCard(
                  referralCode: referralCode,
                  isAbleToRefer: isAbleToRefer,
                ),
                const ReferForm(),
                const SizedBox(height: 16),
                const ReferRewardsCard(),
                HowToReferCard(userRole: userRole),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
