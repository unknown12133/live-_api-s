import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';
import 'package:animal_kart_demo2/profile/screens/referred_users_screen.dart';
import 'package:animal_kart_demo2/utils/custom_page_route.dart';

class ReferRewardsCard extends StatelessWidget {
  const ReferRewardsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        context.tr('Refer & Earn!'),
                        style: tsFont18700.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        context.tr('Get rewards for every unit your friend purchases.'),
                        style: tsFont14400.copyWith(
                          color: kTextSecondary,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                Image.asset(PngImage.refer4, width: 90, height: 90),
              ],
            ),
            const SizedBox(height: 24),
          _buildTierItem(
  context,
  context.tr('Every Unit Purchase'),
  context.tr('Rewards',),
  true,
),
const SizedBox(height: 12),
Padding(
  padding: const EdgeInsets.only(left: 56),
  child: Text(
    context.tr(
      'Rewards apply to every single unit your friend buys. Example: If they buy 3 units, you earn rewards on all 3 units.'
    ),
    style: tsFont12400.copyWith(color: kTextSecondary, height: 1.4),
  ),
),

            const SizedBox(height: 20),
            Center(
              child: TextButton(
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  final mobile = prefs.getString('userMobile');
                  if (mobile != null && mobile.isNotEmpty && context.mounted) {
                    Navigator.push(
                      context,
                      RightToLeftPageRoute(
                        child: ReferralUsersScreen(mobile: mobile),
                      ),
                    );
                  }
                },
                child: Text(
                  context.tr('Track my referrals >'),
                  style: tsFont14700.copyWith(
                    color: Colors.indigo,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTierItem(
    BuildContext context,
    String title,
    String amount,
    bool isAchieved,
  ) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isAchieved ? Colors.green.shade100 : Colors.grey.shade100,
            shape: BoxShape.circle,
          ),
          child: Icon(
            isAchieved ? Icons.military_tech : Icons.military_tech_outlined,
            color: isAchieved ? Colors.orange : Colors.grey,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: tsFont14700.copyWith(fontWeight: FontWeight.w600),
              ),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: amount,
                      style: tsFont18700.copyWith(
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextSpan(
                      text: context.tr(' of unit value as coins'),
                      style: tsFont12400.copyWith(color: kTextSecondary),
                    ),
                  ],
                ),
              ),
              Text(
                context.tr('on each successful referral'),
                style: tsFont12400.copyWith(color: kTextSecondary),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
