import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';
import 'package:animal_kart_demo2/profile/screens/referred_users_screen.dart';
import 'package:animal_kart_demo2/utils/custom_page_route.dart';

class ReferSliverAppBar extends StatelessWidget {
  const ReferSliverAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 320,
      backgroundColor: kPrimaryGreen,
      floating: false,
      pinned: false,
      elevation: 0,
      automaticallyImplyLeading: false, // User wants custom feel
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      flexibleSpace: FlexibleSpaceBar(
        background: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const SizedBox(width: 40), // Spacing for leading if needed
                  const SizedBox(width: 40), // Spacing for leading if needed
                  InkWell(
                    onTap: () async {
                      final prefs = await SharedPreferences.getInstance();
                      final mobile = prefs.getString('userMobile');
                      if (mobile != null &&
                          mobile.isNotEmpty &&
                          context.mounted) {
                        Navigator.push(
                          context,
                          RightToLeftPageRoute(
                            child: ReferralUsersScreen(mobile: mobile),
                          ),
                        );
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            context.tr('My referrals'),
                            style: tsFont14700.copyWith(
                              color: kWhite,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Icon(
                            Icons.chevron_right,
                            color: Colors.white,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                context.tr('Invite friends, earn coins, and convert them into full units.*'),
                style: tsFont20700.copyWith(
                  fontSize: 18,
                  color: kWhite,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStepItem(PngImage.refer6, context.tr('Invite a friend')),
                  const Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                    size: 20,
                  ),
                  _buildStepItem(PngImage.refer5, context.tr('Earn coins')),
                  const Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                    size: 20,
                  ),
                  _buildStepItem(
                    PngImage.femaleMurrah,
                    context.tr('Convert into\nfull units'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  context.tr('*earn on every successful referral'),
                  style: tsFont12400.copyWith(color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStepItem(String imagePath, String label) {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: ClipOval(
              child: Image.asset(
                imagePath,
                width: 70,
                height: 60,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          textAlign: TextAlign.center,
          style: tsFont11700.copyWith(color: kWhite, fontSize: 11),
        ),
      ],
    );
  }
}
