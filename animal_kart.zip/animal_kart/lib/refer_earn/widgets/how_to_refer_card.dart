import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';

class HowToReferCard extends StatelessWidget {
  final String? userRole;
  
  const HowToReferCard({super.key, this.userRole});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          builder: (context) => HowToReferBottomSheet(userRole: userRole),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black12),
        ),
        child: Row(
          children: [
            Image.asset(PngImage.refer3, width: 50, height: 50),
            const SizedBox(width: 12),
             Expanded(
              child: Text(
                context.tr('How to make a successful referral?'),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.indigo),
          ],
        ),
      ),
    );
  }
}

class HowToReferBottomSheet extends StatelessWidget {
  final String? userRole;
  
  const HowToReferBottomSheet({super.key, this.userRole});

  @override
  Widget build(BuildContext context) {
    final role = userRole?.toLowerCase();

final isEmployeeOrSpecial =
    role == 'employee' || role == 'specialcategory';

final isInvestor = role == 'investor';

    // final isEmployee = userRole?.toLowerCase() == 'employee';
    // final isInvestor = userRole?.toLowerCase() == 'investor';
    //SpecialCategory
    
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                context.tr('How to make a successful referral?'),
                style: tsFont14600M.copyWith(fontWeight: FontWeight.bold),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close),
              ),
            ],
          ),
          Text(
            context.tr('How it works'),
            style: tsFont18700.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 24),
          
          // Different content based on user role
          if (isEmployeeOrSpecial) ...[

       //  if (isEmployee) ...[
  _buildStep(
    context,
    context.tr('Start Referring'),
    context.tr('As an employee, you can start referring friends immediately without making any purchase.'),
    true,
  ),
  _buildStep(
    context,
    context.tr('Refer a Friend'),
    context.tr('Enter your friend’s first name, last name, and contact number in the referral form.'),
    true,
  ),
  _buildStep(
    context,
    context.tr('Friend Makes a Purchase'),
    context.tr('When your referred friend joins and purchases a unit, you earn coins based on the unit value.'),
    true,
  ),
  _buildStep(
  context,
  context.tr('Share Your Referral'),
  context.tr(
    'Share your referral directly via WhatsApp or choose any other app from the share options.'
  ),
  true,
),

  _buildStep(
    context,
    context.tr('Employee Bonus'),
    context.tr('As an employee, you receive additional bonus coins for every successful referral.'),
    false,
  ),
]
else ...[
            // Default content for investors
            _buildStep(
              context,
              context.tr('Unlock Referrals'),
              context.tr('Complete your first unit purchase to unlock the referral feature.'),
              true,
            ),
            _buildStep(
              context,
              context.tr('Refer a Friend'),
              context.tr('Enter your friends First Name, Last Name, and Contact Number in the referral form.'),
              true,
            ),
            _buildStep(
              context,
              context.tr('Friends Purchase'),
              context.tr('When your friend joins and buys a unit, you receive coins based on the unit cost.'),
              true,
            ),
            _buildStep(
  context,
  context.tr('Share Your Referral'),
  context.tr(
    'Use WhatsApp direct share or share your referral through any app available on your device.'
  ),
  true,
),

            _buildStep(
              context,
              context.tr('Continuous Rewards'),
              context.tr('You earn rewards for every unit your friend purchases. The more units they buy, the more you earn!'),
              false,
            ),
          ],
          
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildStep(
    BuildContext context,
    String title,
    String description,
    bool hasNext,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            const CircleAvatar(radius: 6, backgroundColor: Colors.indigo),
            if (hasNext) Container(width: 2, height: 60, color: Colors.black12),
          ],
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: tsFont16700.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.indigo,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                description,
                style: tsFont14400.copyWith(color: kTextSecondary),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
