import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/profile/providers/profile_provider.dart';
import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';

class ReferForm extends ConsumerStatefulWidget {
  const ReferForm({super.key});

  @override
  ConsumerState<ReferForm> createState() => _ReferFormState();
}

class _ReferFormState extends ConsumerState<ReferForm> {
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _cityController = TextEditingController();
  
  // Separate loading state for this form only
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _firstNameController.addListener(_onTextChanged);
    _lastNameController.addListener(_onTextChanged);
    _phoneController.addListener(_onTextChanged);
  }

  void _onTextChanged() {
    setState(() {});
  }

  @override
  void dispose() {
    _firstNameController.removeListener(_onTextChanged);
    _lastNameController.removeListener(_onTextChanged);
    _phoneController.removeListener(_onTextChanged);
    _firstNameController.dispose();
    _lastNameController.dispose();
    _phoneController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  bool get _isFormValid {
    return _firstNameController.text.trim().isNotEmpty &&
        _lastNameController.text.trim().isNotEmpty &&
        _phoneController.text.trim().length == 10;
  }

  Future<void> _submitForm() async {
    FocusManager.instance.primaryFocus?.unfocus();
    
    // Set local loading state
    setState(() {
      _isSubmitting = true;
    });

    // Basic Validation
    if (_firstNameController.text.trim().isEmpty) {
      setState(() {
        _isSubmitting = false;
      });
      CustomSnackBar.show(
        context,
        title: 'Error',
        message: 'Please enter first name',
        contentType: ContentType.failure,
      );
      return;
    }
    if (_lastNameController.text.trim().isEmpty) {
      setState(() {
        _isSubmitting = false;
      });
      CustomSnackBar.show(
        context,
        title: 'Error',
        message: 'Please enter last name',
        contentType: ContentType.failure,
      );
      return;
    }
    if (_phoneController.text.trim().length != 10) {
      setState(() {
        _isSubmitting = false;
      });
      CustomSnackBar.show(
        context,
        title: 'Error',
        message: 'Please enter a valid 10-digit mobile number',
        contentType: ContentType.failure,
      );
      return;
    }

    try {
      // Check if user is able to refer
      final profileState = ref.read(profileProvider);
      final currentUser = profileState.currentUser;

      if (currentUser == null || !currentUser.isAbleToRefer) {
        setState(() {
          _isSubmitting = false;
        });
        if (mounted) {
          CustomSnackBar.show(
            context,
            title: 'Not Eligible to Refer',
            message:
                'You have not purchased any units yet, so you are not eligible to Refer & Earn.',
            contentType: ContentType.failure,
          );
        }
        return;
      }

      await ref
          .read(profileProvider.notifier)
          .createReferralUser(
            firstName: _firstNameController.text.trim(),
            lastName: _lastNameController.text.trim(),
            mobile: _phoneController.text.trim(),
          );

      final state = ref.read(profileProvider);

      if (mounted) {
        if (state.createUserResponse != null) {
          final bool isSuccess =
              state.createUserResponse!.status.toLowerCase() == 'success';

          CustomSnackBar.show(
            context,
            title: isSuccess ? 'Success' : 'Failed',
            message: state.createUserResponse!.message,
            contentType: isSuccess ? ContentType.success : ContentType.failure,
            color: isSuccess ? kPrimaryGreen : null,
            isReferral: true,
          );
          
          // Reset form and clear the response state immediately
          _firstNameController.clear();
          _lastNameController.clear();
          _phoneController.clear();
          ref.read(profileProvider.notifier).resetCreateUserState();
        } else if (state.error != null) {
          CustomSnackBar.show(
            context,
            title: 'Error',
            message: state.error!,
            contentType: ContentType.failure,
          );
          // Clear error state as well
          ref.read(profileProvider.notifier).resetCreateUserState();
        }
      }
    } catch (e) {
      if (mounted) {
        CustomSnackBar.show(
          context,
          title: 'Error',
          message: 'An unexpected error occurred: $e',
          contentType: ContentType.failure,
        );
      }
    } finally {
      // Always reset loading state
      setState(() {
        _isSubmitting = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(profileProvider);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Image.asset(PngImage.refer1, width: 50, height: 40),
              const SizedBox(width: 8),
              Text(
                context.tr('Submit a contact to earn rewards'),
                style: tsFont16700.copyWith(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildTextField(
            context.tr('First Name *'),
            _firstNameController,
            maxLength: 30,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
              LengthLimitingTextInputFormatter(30),
            ],
          ),
          const SizedBox(height: 12),
          _buildTextField(
            context.tr('Last Name *'),
            _lastNameController,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
            ],
          ),
          const SizedBox(height: 12),
          _buildTextField(
            context.tr(" Friends contact number *"),
            _phoneController,
            keyboardType: TextInputType.phone,
            prefixText: '+91 ',
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(10),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: (_isSubmitting || !_isFormValid)
                  ? null
                  : _submitForm,
              style: ElevatedButton.styleFrom(
                backgroundColor: kPrimaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
              ),
              child: _isSubmitting
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: kWhite,
                        strokeWidth: 2,
                      ),
                    )
                  : Text(
                      context.tr('Submit'),
                      style: tsFont16700.copyWith(color: kWhite),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(
    String hint,
    TextEditingController controller, {
    Widget? suffix,
    List<TextInputFormatter>? inputFormatters,
    TextInputType? keyboardType,
    int? maxLength,
    String? prefixText,
  }) {
    return TextField(
      controller: controller,
      inputFormatters: inputFormatters,
      keyboardType: keyboardType,
      maxLength: maxLength,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: tsFont14400.copyWith(color: kTextHint),
        prefixText: prefixText,
        prefixStyle: tsFont14400.copyWith(color: kTextPrimary),
        counterText: "", // Hide the character counter
        filled: true,
        fillColor: const Color(0xFFF9F9F9),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.black12),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.black12),
        ),
        suffixIcon: suffix,
      ),
    );
  }
}
