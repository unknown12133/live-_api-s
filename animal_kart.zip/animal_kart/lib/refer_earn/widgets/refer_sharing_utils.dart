String getReferralShareMessage(String referralCode) {
  return '''
Hey!
I’m investing through AnimalKart – a trusted platform for structured buffalo unit investments.

Why invest alone, when you can grow together?

✅ 1 Unit = 2 Murrah buffaloes + 2 calves
✅ Transparent income projections
✅ Long-term asset value (10-year growth)
✅ Optional Cattle Protection Fund (CPF) with special offers
✅ Fully managed & tracked through the AnimalKart app


👉 Click below to explore AnimalKart and start your journey:
https://dashboard.markwave.ai/referral-landing?referral_code=$referralCode&alk_campaign=subscriber_referral&animalkart=app&utm_source=whatsapp_share_button
''';
}
