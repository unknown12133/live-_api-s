import 'dart:ui';
import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';
import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
import 'refer_sharing_utils.dart';

class ReferWhatsAppCard extends StatelessWidget {
  final String referralCode;
  final bool isAbleToRefer; // Added field

  const ReferWhatsAppCard({
    super.key,
    required this.referralCode,
    required this.isAbleToRefer, // Added required parameter
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.green.withOpacity(0.1)),
      ),
      color: const Color(0xFFF1FDF6),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              children: [
                Image.asset(
                  PngImage.WhatsAppIcon,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        context.tr('Refer via WhatsApp'),
                        style: tsFont18700.copyWith(
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF2E7D32),
                        ),
                      ),
                      Text(
                        context.tr(
                          'Share your referral code and earn on a successful referral',
                        ),
                        style: tsFont14400.copyWith(
                          color: kTextSecondary,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            CustomPaint(
              painter: DashedBorderPainter(
                color: Colors.green.withOpacity(1),
                strokeWidth: 1,
                gap: 5,
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.white,
                ),
                child: Row(
                  children: [
                    Text(
                      context.tr('Referral\ncode'),
                      style: tsFont12400.copyWith(color: kTextSecondary),
                    ),
                    const Spacer(),
                    Text(
                      referralCode,
                      style: tsFont18700.copyWith(
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        color: kTextPrimary,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: referralCode));
                        CustomSnackBar.show(
                          context,
                          title: "Success",
                          message: context.tr('Code copied to clipboard'),
                          contentType: ContentType.success,
                          isReferral: true, // ✅ SHOW PERSON ICON FOR SHARING
                        );
                      },
                      icon: const Icon(Icons.copy, color: kPrimaryGreen),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      if (!isAbleToRefer) {
                        // ✅ FIX: USE CUSTOM SNACKBAR INSTEAD OF DEFAULT
                        CustomSnackBar.show(
                          context,
                          title: "Not Eligible",
                          message: context.tr('You are not eligible to refer'),
                          contentType: ContentType.failure,
                          isReferral: true, // ✅ SHOW PERSON ICON FOR SHARING
                        );
                        return;
                      }
                      final String shareMessage = getReferralShareMessage(
                        referralCode,
                      );
                      Share.share(shareMessage);
                    },
                    icon: const Icon(Icons.share, size: 20),
                    label: Text(context.tr('Share')),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6366F1),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 5,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      if (!isAbleToRefer) {
                        CustomSnackBar.show(
                          context,
                          title: "Not Eligible",
                          message: context.tr('You are not eligible to refer'),
                          contentType: ContentType.failure,
                          isReferral: true,
                        );
                        return;
                      }

                      final String shareMessage = getReferralShareMessage(
                        referralCode,
                      );

                      // // Try web WhatsApp URL first (works better on iOS)
                      // final Uri whatsappWebUrl = Uri.parse(
                      //   "https://wa.me/?text=${Uri.encodeComponent(shareMessage)}",
                      // );

                      // if (await canLaunchUrl(whatsappWebUrl)) {
                      //   await launchUrl(
                      //     whatsappWebUrl,
                      //     mode: LaunchMode.externalApplication,
                      //   );
                      // } else {
                      //   // Fallback to native WhatsApp URL scheme
                      //   final Uri whatsappNativeUrl = Uri.parse(
                      //     "whatsapp://send?text=${Uri.encodeComponent(shareMessage)}",
                      //   );

                      //   if (await canLaunchUrl(whatsappNativeUrl)) {
                      //     await launchUrl(whatsappNativeUrl);
                      //   } else {
                      //     // ✅ FIX: USE CUSTOM SNACKBAR INSTEAD OF DEFAULT
                      //     CustomSnackBar.show(
                      //       context,
                      //       title: "Error",
                      //       message: context.tr(
                      //         "WhatsApp is not installed on this device",
                      //       ),
                      //       contentType: ContentType.failure,
                      //       isReferral: true,
                      //     );
                      //   }
                      // }

                      // ✅ UNIVERSAL WHATSAPP URL (Works on Web, Android, iOS)
                      final String url =
                          "https://wa.me/?text=${Uri.encodeComponent(shareMessage)}";
                      final Uri uri = Uri.parse(url);
                      if (await canLaunchUrl(uri)) {
                        try {
                          // On Web or if WhatsApp is installed, this will open the correct app/tab
                          await launchUrl(
                            uri,
                            mode: LaunchMode.externalApplication,
                          );
                        } catch (e) {
                          CustomSnackBar.show(
                            context,
                            title: "Error",
                            message: context.tr("Could not open WhatsApp"),
                            contentType: ContentType.failure,
                            isReferral: true,
                          );
                        }
                      } else {
                        // Fallback to native WhatsApp URL scheme
                        final Uri whatsappNativeUrl = Uri.parse(
                          "whatsapp://send?text=${Uri.encodeComponent(shareMessage)}",
                        );

                        if (await canLaunchUrl(whatsappNativeUrl)) {
                          await launchUrl(whatsappNativeUrl);
                        } else {
                          // ✅ FIX: USE CUSTOM SNACKBAR INSTEAD OF DEFAULT
                          CustomSnackBar.show(
                            context,
                            title: "Error",
                            message: context.tr(
                              "WhatsApp is not installed on this device",
                            ),
                            contentType: ContentType.failure,
                            isReferral: true, // ✅ SHOW PERSON ICON FOR SHARING
                          );
                        }
                      }
                    },
                    icon: Image.asset(
                      PngImage.WhatsAppIcon,
                      width: 44,
                      height: 44,
                    ),
                    label: Text(context.tr('Refer on WhatsApp')),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryGreen,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class DashedBorderPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final double gap;

  DashedBorderPainter({
    required this.color,
    this.strokeWidth = 1.0,
    this.gap = 5.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final double dashWidth = gap;
    final double dashSpace = gap;
    final RRect rrect = RRect.fromLTRBR(
      0,
      0,
      size.width,
      size.height,
      const Radius.circular(12),
    );

    final Path path = Path()..addRRect(rrect);

    final Path dashedPath = Path();
    for (final PathMetric pathMetric in path.computeMetrics()) {
      double distance = 0.0;
      while (distance < pathMetric.length) {
        dashedPath.addPath(
          pathMetric.extractPath(distance, distance + dashWidth),
          Offset.zero,
        );
        distance += dashWidth + dashSpace;
      }
    }
    canvas.drawPath(dashedPath, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
