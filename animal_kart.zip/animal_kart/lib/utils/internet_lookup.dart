import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class InternetAccess {
  static Future<bool> hasActualAccess() async {
    // 1. Check basic connectivity (is Wi-Fi/Mobile data on?)
    final connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult.contains(ConnectivityResult.none) ||
        connectivityResult.isEmpty) {
      return false;
    }

    // 2. Performance real-world check (can we actually reach a server?)
    // On web, we cannot use Socket lookup due to CORS, so we do a simple HEAD request.
    if (kIsWeb) {
      // On web, we trust the browser's connectivity state (navigator.onLine).
      // External pings often fail due to CORS even when online.
      return true;
    }

    // On Mobile, we do a DNS lookup which is faster and more reliable than a full HTTP request.
    try {
      // Check multiple reliable hosts + our specific API host
      final hosts = [
        'google.com',
        'animalkart-live-apis-jn6cma3vvq-el.a.run.app',
        'cloudflare.com',
      ];
      for (var host in hosts) {
        try {
          final result = await InternetAddress.lookup(
            host,
          ).timeout(const Duration(seconds: 2));
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            return true;
          }
        } catch (_) {
          continue;
        }
      }
      return false;
    } catch (_) {
      return false;
    }
  }
}
