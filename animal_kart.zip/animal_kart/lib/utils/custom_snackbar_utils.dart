import 'package:animal_kart_demo2/utils/png_images.dart';
import 'package:flutter/material.dart';
import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
export 'package:awesome_snackbar_content/awesome_snackbar_content.dart';

class CustomSnackBar {
  static void show(
    BuildContext context, {
    required String title,
    required String message,
    required ContentType contentType,
    bool isReferral = false,
    Color? color,
    Duration duration = const Duration(seconds: 1, milliseconds: 250),
  }) {
    final snackBarColor = color ?? _getColor(contentType);
    
    ScaffoldMessenger.of(context)
      ..removeCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          elevation: 0,
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.transparent,
          duration: duration,
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          content: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: color ?? _getColor(contentType),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                
                SizedBox(
                  height: 32,
                  width: 32,
                    child: isReferral
                        ? const Icon(
                          Icons.person_outline,
                            color: Colors.white,
                          size: 28,
                          )
                        : Image.asset(
                            PngImage.femaleMurrah,
                            fit: BoxFit.contain,
                          ),
                  ),

                const SizedBox(width: 10),
//  Text(
//                               title,
//                               style: const TextStyle(
//                                 fontSize: 18,
//                                 fontWeight: FontWeight.bold,
//                                 color: Colors.white,
//                               ),
//                             ),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                    
                      const SizedBox(height: 2),
                      Text(
                        message,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.white,
                          height: 1.2,
                          fontWeight: FontWeight.w500,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon: const Icon(
                    Icons.close_rounded,
                    color: Colors.white70,
                    size: 20,
                  ),
                  onPressed: () {
                    ScaffoldMessenger.of(context).hideCurrentSnackBar();
                  },
                ),
              ],
            ),
          ),
        ),
      );
  }

  static Color _getColor(ContentType contentType) {
    if (contentType == ContentType.success) return const Color(0xFF238E8B);
    if (contentType == ContentType.failure) return const Color(0xFFC72C41);
    if (contentType == ContentType.help) return const Color(0xFF3282B8);
    if (contentType == ContentType.warning) return const Color(0xFFFCA652);
    return const Color(0xFF238E8B);
  }
}


