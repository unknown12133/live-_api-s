class PngImage {
  static const String _basePath = 'assets/images';

  static const String refer1 = '$_basePath/refer_1.png';
  static const String refer2 = '$_basePath/refer_2.png';
  static const String refer3 = '$_basePath/refer_3.png';
  static const String refer4 = '$_basePath/refer_4.png';
  static const String refer5 = '$_basePath/refer_5.png';
  static const String refer6 = '$_basePath/refer_6.png';
  static const String WhatsAppIcon = '$_basePath/whats_app.png';

  static const String appLogo = '$_basePath/onboard_logo.png';
  static const String appLogo1 = '$_basePath/onboard_logo1.png';
  static const String appName = '$_basePath/app_name_text.png';
  static const String coin = '$_basePath/coin.png';
  static const String coinDetails = '$_basePath/coin_details.png';
  static const String buffalo1 = '$_basePath/buffalo_image1.png';
  static const String buffalo2 = '$_basePath/buffalo_image2.png';
  static const String buffalo3 = '$_basePath/buffalo_image3.png';
  static const String femaleMurrah = '$_basePath/BUffaloGrazing.png';
}
