import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

// Font Size Constants
const double fs10 = 10.0;
const double fs11 = 11.0;
const double fs12 = 12.0;
const double fs13 = 13.0;
const double fs14 = 14.0;
const double fs15 = 15.0;
const double fs16 = 16.0;
const double fs17 = 17.0;
const double fs18 = 18.0;
const double fs20 = 20.0;
const double fs22 = 22.0;
const double fs23 = 23.0;
const double fs24 = 24.0;
const double fs30 = 30.0;
const double fs36 = 36.0;

// Styles
TextStyle tsFont24Bold = GoogleFonts.roboto(
  fontSize: fs24,
  fontWeight: FontWeight.w800,
  color: kBlack1,
);

TextStyle tsFont12400 = GoogleFonts.inter(
  fontSize: fs12,
  fontWeight: FontWeight.w400,
  color: kBlack,
);

TextStyle tsFont12700 = GoogleFonts.inter(
  fontSize: fs12,
  fontWeight: FontWeight.w700,
  color: kBlack1,
);

TextStyle tsFont12700_1 = GoogleFonts.inter(
  fontSize: fs12,
  fontWeight: FontWeight.w700,
  color: kTextSecondary,
);

TextStyle tsFont14900 = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w900,
  color: kTextDarkGray,
);

TextStyle tsFont14600_2 = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w600,
  color: kPrimaryRed,
);

TextStyle tsFont36Bold = GoogleFonts.roboto(
  fontSize: fs36,
  fontWeight: FontWeight.bold,
  color: kWhite,
);

TextStyle tsFont17900 = GoogleFonts.roboto(
  fontSize: fs17,
  fontWeight: FontWeight.w900,
  color: kBlack,
);

TextStyle tsFont14600 = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w600,
  color: kTextDarkGray,
);

TextStyle tsFont14600M = GoogleFonts.inter(
  fontSize: fs15,
  fontWeight: FontWeight.w600,
  color: kBlack,
);

TextStyle tsFont14700_BrandColor_Italic = GoogleFonts.inter(
  fontSize: fs14,
  color: flyttaColor,
  fontStyle: FontStyle.italic,
  decoration: TextDecoration.underline,
);

TextStyle tsFont14700_Italic = GoogleFonts.inter(
  fontSize: fs14,
  color: kBlack,
  fontStyle: FontStyle.italic,
  decoration: TextDecoration.underline,
);

TextStyle tsFont16700 = GoogleFonts.roboto(
  fontSize: fs16,
  fontWeight: FontWeight.w700,
  color: kBlack,
);

TextStyle tsFont18700 = GoogleFonts.roboto(
  fontSize: fs18,
  fontWeight: FontWeight.w700,
  color: kBlack,
);
TextStyle tsFont17700a = GoogleFonts.roboto(
  fontSize: fs17,
  fontWeight: FontWeight.w700,
  color: Colors.amber.shade700,
);

TextStyle tsFont18400 = GoogleFonts.roboto(
  fontSize: fs18,
  fontWeight: FontWeight.w400,
  color: kBlack,
);

TextStyle tsFont18600 = GoogleFonts.roboto(
  fontSize: fs18,
  fontWeight: FontWeight.w600,
  color: kTextLightGray,
);

TextStyle tsFont218400 = GoogleFonts.roboto(
  fontSize: fs18,
  fontWeight: FontWeight.w400,
  color: kWhite,
);

TextStyle tsFont218400_1 = GoogleFonts.roboto(
  fontSize: fs18,
  fontWeight: FontWeight.w400,
  color: kBlack,
);

TextStyle tsFont16700_3 = GoogleFonts.roboto(
  fontSize: fs16,
  fontWeight: FontWeight.w700,
  color: kBlack,
);

TextStyle tsFont16700_4 = GoogleFonts.roboto(
  fontSize: fs16,
  fontWeight: FontWeight.w700,
  color: kWhite,
);

TextStyle tsFont23500 = GoogleFonts.roboto(
  fontSize: fs23,
  fontWeight: FontWeight.w500,
  color: kBlack,
);

TextStyle tsFont15400 = GoogleFonts.inter(
  fontSize: fs15,
  fontWeight: FontWeight.w400,
  color: kTextSecondary,
);

TextStyle tsFont14400 = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w400,
  color: kTextSecondary,
);

TextStyle tsFont14400_Black = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w400,
  color: kBlack,
);

TextStyle tsFont14300 = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w300,
  color: kBlack,
);

TextStyle tsFont13900 = GoogleFonts.inter(
  fontSize: fs13,
  fontWeight: FontWeight.w900,
  color: kBlack,
);
TextStyle tsFont13800 = GoogleFonts.inter(
  fontSize: fs13,
  fontWeight: FontWeight.w800,
  color: kBlack,
);


TextStyle tsFont20500 = GoogleFonts.roboto(
  fontSize: fs20,
  fontWeight: FontWeight.w500,
  color: kBlack,
);

TextStyle tsFont16900 = GoogleFonts.roboto(
  fontSize: fs16,
  fontWeight: FontWeight.w900,
  color: kBlack,
);

TextStyle tsFont20700 = GoogleFonts.roboto(
  fontSize: fs20,
  fontWeight: FontWeight.w700,
  color: kBlack,
);
TextStyle tsFont18500 = GoogleFonts.roboto(
  fontSize: fs18,
  fontWeight: FontWeight.w500,
  color: kBlack,
);
TextStyle tsFont11700 = GoogleFonts.inter(
  fontSize: fs10,
  fontWeight: FontWeight.w700,
  color: kBlack,
);
TextStyle tsFont24700 = GoogleFonts.roboto(
  fontSize: fs24,
  fontWeight: FontWeight.w700,
  color: kBlack,
);

TextStyle tsFont24500 = GoogleFonts.roboto(
  fontSize: fs24,
  fontWeight: FontWeight.w500,
  color: kBlack,
);

TextStyle tsFont14400_1 = GoogleFonts.inter(
  fontSize: fs14,
  fontWeight: FontWeight.w400,
  color: kBlack,
);

TextStyle tsFont16400_1 = GoogleFonts.inter(
  fontSize: fs16,
  fontWeight: FontWeight.w400,
  color: kTextSecondary,
);

TextStyle tsFont16400 = GoogleFonts.inter(
  fontSize: fs16,
  fontWeight: FontWeight.w400,
  color: kBlack,
);

TextStyle tsFont16400_Gotham = GoogleFonts.roboto(
  fontSize: fs16,
  fontWeight: FontWeight.w600,
  color: kBlack,
);

TextStyle tsFont16700N = GoogleFonts.inter(
  fontSize: fs16,
  fontWeight: FontWeight.w700,
  color: kBlack,
);

TextStyle tsFont15900 = GoogleFonts.inter(
  fontSize: fs15,
  fontWeight: FontWeight.w900,
  color: kBlack,
);

TextStyle tsFont30500 = GoogleFonts.roboto(
  fontSize: fs30,
  fontWeight: FontWeight.w500,
  color: const Color(0xffDADADA),
);

TextStyle tsFont20500_1 = GoogleFonts.roboto(
  fontSize: fs20,
  fontWeight: FontWeight.w500,
  color: const Color(0xffDADADA),
);
TextStyle tsFont14700 = GoogleFonts.roboto(
  fontSize: fs14,
  fontWeight: FontWeight.w700,
  color: kBlack,
  
);
TextStyle tsFont15700 = GoogleFonts.roboto(
  fontSize: fs15,
  fontWeight: FontWeight.w700,
  color: kBlack,
  
);

// Aliases
TextStyle tsFont12400_Gotham = tsFont12400;
TextStyle tsFont18700_Gotham = tsFont18700;
TextStyle tsFont12700_Gotham = tsFont12700;
TextStyle tsFont16700_Gotham = tsFont16700;
TextStyle tsFont14700_Gotham = tsFont14600M;
TextStyle tsFont20400 = GoogleFonts.roboto(
  fontSize: fs20,
  fontWeight: FontWeight.w400,
  color: kBlack,
);
TextStyle tsFont20700_Gotham = tsFont20700;
TextStyle tsFont11700_Gotham = tsFont11700;
TextStyle tsFont24700_Gotham = tsFont24500;
TextStyle tsFont15700_Gotham = tsFont14600M;
TextStyle tsFont22700 = GoogleFonts.roboto(
  fontSize: fs22,
  fontWeight: FontWeight.w700,
  color: kBlack,
);
