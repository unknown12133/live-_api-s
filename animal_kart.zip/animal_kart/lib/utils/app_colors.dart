import 'package:flutter/material.dart';

// Brand Colors
const Color kPrimaryGreen = Color(0xFF238E8B);
const Color kPrimaryDarkGreen = Color(0xFF1A6B69);
const Color kAccentLime = Color(0xFFE7EE57);
const Color flyttaColor = kPrimaryGreen;

// Secondary Colors
const Color kPrimaryRed = Color(0xFFD8281C);
const Color kSecondaryRed = Color(0xFFC71720);
const Color kSuccessGreen = Color(0XFF1A873C);
const Color kWarningOrange = Color(0XFFE66811);

// Neutral Colors
const Color kBlack = Color(0xFF000000);
const Color kBlack1 = Color(0xFF111827);
const Color kWhite = Color(0xFFFFFFFF);

// Text Colors
const Color kTextPrimary = Color(0xFF000000);
const Color kTextSecondary = Color(0xFF6C6C6C);
const Color kTextHint = Colors.grey;
const Color kTextDarkGray = Color(0xFF4B5563);
const Color kTextLightGray = Color(0xFF6B7280);

// Background & Surface
const Color kScreenBg = Color(0xFFF4F4F4);
const Color kFieldBg = Color(0xFFF2F2F2);
const Color kCardBg = Colors.white;
const Color kBorderColor = Color(0xFFD7E2EB);
const Color kDividerColor = Color(0xFFF3F3F3);

// Legacy/Aliases for compatibility
const Color kPrimaryColor = kPrimaryGreen;
const Color kPrimaryDarkColor = kPrimaryGreen;
const Color kBackgroundColor = kScreenBg;
