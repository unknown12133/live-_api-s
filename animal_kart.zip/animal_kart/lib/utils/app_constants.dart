import 'package:animal_kart_demo2/onboarding/models/onboarding_data.dart';
import 'package:intl/intl.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

const String kRobotoBold = 'RobotoBold';
const String kRoboto = 'Roboto';
const String kRobotoMedium = 'RobotoMedium';

class AppConstants {
  //common Constants
  static Duration kToastAnimDuration = Duration(milliseconds: 600);
  static Duration kToastDuration = Duration(milliseconds: 1800);
  static String kAppName = 'ANIMAL\nKART';
  static String countryCode = "+91";
  static String khyphen = "--";
  static String storageBucketName = 'gs://markwave-481315.firebasestorage.app';

  //Api constants
  static String apiUrl =
      dotenv.env['API_URL'] ??
      'https://animalkart-live-apis-jn6cma3vvq-el.a.run.app';

  static const String applicationJson = 'application/json';

  //assets String
  static String appLogoAssert = 'assets/images/onboard_logo.png';
  static String onBoardAppLogo = "assets/images/onboard_logo.png";
  static String AppNameAsset = "assets/images/app_name_text.png";
  static String coinImage = "assets/images/coin.png";
  static String coinDetailsImage = "assets/images/coin_details.png";

  //onboarding lsit
  static List<OnboardingData> onboardingData = [
    OnboardingData(
      image: "assets/images/BUffaloGrazing.png",
      subtitle:
          "Discover,hire and manage buffalo carts easily - anytime,anywhere",
      title: "Your Buffalo Cart Partner.",
    ),
    OnboardingData(
      image: "assets/images/buff.png",
      subtitle:
          "Choose near by buffalo carts with transparent pricing and trusted owners",
      title: "Find the Cart  in Second.",
    ),
    OnboardingData(
      image: "assets/images/buffaloAdobe.png",
      subtitle: "Live updates quick support,and smooth payments in one place",
      title: "Track Your Ride - Free",
    ),
  ];
  String formatIndianAmount(num amount) {
    final formatter = NumberFormat.decimalPattern('en_IN');
    return formatter.format(amount);
  }
}
