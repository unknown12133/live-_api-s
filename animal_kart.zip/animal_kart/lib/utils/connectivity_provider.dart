import 'package:animal_kart_demo2/utils/internet_lookup.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

enum ConnectionStatus { connected, disconnected }

final connectivityProvider = StreamProvider<ConnectionStatus>((ref) async* {
  final connectivity = Connectivity();

  // Helper function to check real access
  Future<ConnectionStatus> checkRealAccess() async {
    final hasAccess = await InternetAccess.hasActualAccess();
    return hasAccess
        ? ConnectionStatus.connected
        : ConnectionStatus.disconnected;
  }

  // Initial check
  yield await checkRealAccess();

  // Listen for changes
  await for (final _ in connectivity.onConnectivityChanged) {
    yield await checkRealAccess();
  }
});
