import 'package:image_picker/image_picker.dart';
import 'package:animal_kart_demo2/widgets/web_safe_image.dart';
import 'dart:io' as io;
import 'package:flutter/foundation.dart';
import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/svg_utils.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:animal_kart_demo2/utils/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AadhaarUploadWidget extends ConsumerWidget {
  final XFile? file;
  final String title;
  final VoidCallback onRemove;
  final VoidCallback onCamera;
  final VoidCallback onGallery;
  final bool isFrontImage;
  final double? uploadProgress;
  final bool isCompressing;

  const AadhaarUploadWidget({
    super.key,
    required this.file,
    required this.title,
    required this.onRemove,
    required this.onCamera,
    required this.onGallery,
    this.isFrontImage = true,
    this.uploadProgress,
    this.isCompressing = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              context.tr(title),
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 12),

            if (file != null)
              _buildFilePreview(context)
            else if (isCompressing)
              _buildCompressingView()
            else
              _buildUploadButtons(context),
          ],
        ),
      ),
    );
  }

  Widget _buildCompressingView() {
    return Container(
      height: 150,
      width: double.infinity,
      color: Colors.grey.shade100,
      child: const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
             SizedBox(height: 10),
            Text("Compressing image..."),
          ],
        ),
      ),
    );
  }

  Widget _buildFilePreview(BuildContext context) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(
            children: [
              kIsWeb
                  ? WebSafeImage(
                      imageUrl: file!.path,
                      height: 150,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    )
                  : Image.file(
                      io.File(file!.path),
                      height: 150,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      key: ValueKey(file!.path),
                    ),
              if (uploadProgress != null)
                Positioned.fill(
                  child: Container(
                    color: Colors.black26,
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(
                            value: uploadProgress,
                            backgroundColor: Colors.grey[200],
                            valueColor: AlwaysStoppedAnimation<Color>(
                              kPrimaryGreen,
                            ),
                            strokeWidth: 4,
                          ),
                          const SizedBox(height: 8),
                          if (uploadProgress != null)
                            Text(
                              '${(uploadProgress! * 100).toStringAsFixed(0)}%',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        Positioned(
          top: 4,
          right: 4,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: onRemove,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 4,
                  ),
                ],
              ),
               child: SvgPicture.string(
                SvgUtils().deleteIcon,
                colorFilter: ColorFilter.mode(
                  akRedColor,
                  BlendMode.srcIn,

                  // color: akRedColor,
                ),
              ),
              // child: const Icon(
              //   Icons.delete,
              //   color: akRedColor,
              //   size: 20,
              // ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUploadButtons(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: Column(
            children: [
              const Icon(
                Icons.cloud_upload_outlined,
                size: 55,
                color: Colors.grey,
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: onGallery,
                child: Text(
                  context.tr("uploadImage"),
                  style: const TextStyle(fontSize: 18),
                ),
              ),
              Text(context.tr("uploadPhotosNote")),
              Text(
                context.tr("(or)"),
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: kPrimaryColor,
                ),
              ),
              const SizedBox(height: 6),
              ElevatedButton(
                onPressed: onCamera,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPrimaryGreen,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
                child: Text(
                  context.tr("openCamera"),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
