
import 'package:animal_kart_demo2/auth/widgets/date_inputformatter_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


class PersonalInfoSection extends StatefulWidget {
  final TextEditingController firstNameCtrl;
  final TextEditingController lastNameCtrl;
  final TextEditingController occupationCtrl;
  final TextEditingController dobCtrl;
  final FocusNode? firstNameFocus;
  final Function() onSelectDOB;
  final Function() onDOBCleared; 
  final String gender;
  final Function(String) onGenderChanged;

  const PersonalInfoSection({
    super.key,
    required this.firstNameCtrl,
    required this.lastNameCtrl,
    required this.occupationCtrl,
    required this.dobCtrl,
    this.firstNameFocus,
    required this.onSelectDOB,
    required this.onDOBCleared,
    required this.gender,
    required this.onGenderChanged,
  });

  @override
  State<PersonalInfoSection> createState() => _PersonalInfoSectionState();
}

class _PersonalInfoSectionState extends State<PersonalInfoSection> {
  String? _dobError;

String? _validateDOB(String value) {
  if (value.isEmpty) return "* Required";

  
  if (value.length == 10 && value.contains('-')) {
    try {
      final parts = value.split('-');
      if (parts.length != 3) return "Invalid date format";

      final day = int.parse(parts[0]);
      final month = int.parse(parts[1]);
      final year = int.parse(parts[2]);
      final dob = DateTime(year, month, day);
      final today = DateTime.now();

      // Check future date
      if (dob.isAfter(today)) return "Date cannot be in future";

      // Check age
      int age = today.year - dob.year;
      if (today.month < dob.month ||
          (today.month == dob.month && today.day < dob.day)) {
        age--;
      }

      if (age < 18) return "Age must be at least 18 years";

      return null; // ✅ valid
    } catch (e) {
      return "Invalid date format";
    }
  }

  
  return null;
}
@override
void initState() {
  super.initState();

  // Listen to any change in dobCtrl
  widget.dobCtrl.addListener(() {
    setState(() {
      _dobError = _validateDOB(widget.dobCtrl.text);
      
      
      if (widget.dobCtrl.text.trim().isEmpty) {
        widget.onDOBCleared();
      }
    });
  });
}

// @override
// void dispose() {
//   widget.dobCtrl.removeListener(() {}); // optional cleanup
//   super.dispose();
// }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Personal Information",
          style: TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 10),
        Card(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "First Name",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 8),
                TextFormField(
  controller: widget.firstNameCtrl,
  focusNode: widget.firstNameFocus,
  autovalidateMode: AutovalidateMode.onUserInteraction,
  keyboardType: TextInputType.name, // 👈 NO number keypad
  textCapitalization: TextCapitalization.words,
  textInputAction: TextInputAction.next,
  maxLength: 30, // 👈 limit length
  inputFormatters: [
    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
  ],
  decoration: _fieldDeco("First Name").copyWith(
    counterText: "", // hides 0/30 counter
  ),
  validator: (v) {
    if (v == null || v.trim().isEmpty) {
      return "First name is required";
    }
    if (v.trim().length < 2) {
      return "Enter at least 2 characters";
    }
    return null;
  },
),

                const SizedBox(height: 15),
                const Text(
                  "Family Name",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 8),
               TextFormField(
  controller: widget.lastNameCtrl,
  autovalidateMode: AutovalidateMode.onUserInteraction,
  keyboardType: TextInputType.name, // 👈 alphabet keyboard
  textCapitalization: TextCapitalization.words,
  textInputAction: TextInputAction.next,
  maxLength: 30,
  inputFormatters: [
    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
  ],
  decoration: _fieldDeco("Family Name").copyWith(
    counterText: "",
  ),
  validator: (v) {
    if (v == null || v.trim().isEmpty) {
      return "Family name is required";
    }
    return null;
  },
),


                const SizedBox(height: 20),
                const Text("Gender"),
Wrap(
  spacing: 16,
  runSpacing: 10,
  children: [
    _genderOption("Male"),
    _genderOption("Female"),
    _genderOption("Others"),
  ],
),


                const SizedBox(height: 20),
const Text(
  "Occupation",
  style: TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
  ),
),
const SizedBox(height: 8),
TextFormField(
  controller: widget.occupationCtrl,
  autovalidateMode: AutovalidateMode.onUserInteraction,
  keyboardType: TextInputType.name,
  textCapitalization: TextCapitalization.words,
  inputFormatters: [
    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')), 
    LengthLimitingTextInputFormatter(30), 
  ],
  decoration: _fieldDeco("Occupation"),
  validator: (v) {
    if (v == null || v.trim().isEmpty) {
      return "Occupation is required";
    }
    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(v.trim())) {
      return "Only letters allowed";
    }
    return null;
  },
),


                const SizedBox(height: 15),
                const Text(
                  "Date of Birth",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 8),
TextFormField(
  controller: widget.dobCtrl,
  keyboardType: TextInputType.number,
  autovalidateMode: AutovalidateMode.onUserInteraction,
  inputFormatters: [
    FilteringTextInputFormatter.digitsOnly,
    LengthLimitingTextInputFormatter(8),
    DateInputFormatter(), // auto adds dashes
  ],
  decoration: _fieldDeco("DD-MM-YYYY").copyWith(
    suffixIcon: IconButton(
      icon: const Icon(Icons.calendar_month),
      onPressed: widget.onSelectDOB,
    ),
    errorText: _dobError, 
  ),
  onChanged: (value) {
    setState(() {
      _dobError = _validateDOB(value);
    });
  },
),



                const SizedBox(height: 6),

              ],
            ),
          ),
        ),
      ],
    );
  }


  Widget _genderOption(String label) {
  return InkWell(
    onTap: () => widget.onGenderChanged(label),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Radio<String>(
          value: label,
          groupValue: widget.gender,
          onChanged: (val) => widget.onGenderChanged(val!),
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          visualDensity: const VisualDensity(
            horizontal: VisualDensity.minimumDensity,
            vertical: VisualDensity.minimumDensity,
          ),
        ),
        const SizedBox(width: 4), // 🔥 CONTROL SPACE HERE
        Text(
          label,
          style: const TextStyle(fontSize: 14),
        ),
      ],
    ),
  );
}

  InputDecoration _fieldDeco(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: const Color(0xFFF5F5F5),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 15,
        vertical: 15,
      ),
    );
  }
}