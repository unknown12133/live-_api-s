import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/auth/widgets/aadhar_upload_widget.dart';
import 'package:animal_kart_demo2/manualpayment/widgets/upload_image_widget.dart';
import 'package:animal_kart_demo2/auth/providers/user_provider.dart';
import 'package:animal_kart_demo2/auth/providers/pincode_provider.dart';
import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';

class AddressDocumentsSection extends ConsumerStatefulWidget {
  final TextEditingController pincodeCtrl;
  final TextEditingController cityCtrl;
  final TextEditingController stateCtrl;
  final TextEditingController aadhaarCtrl;

  final bool isCompressingAadhaarFront;
  final bool isCompressingAadhaarBack;
  final bool isCompressingPan;
  final bool isDeletingAadhaarFront;
  final bool isDeletingAadhaarBack;
  final bool isDeletingPan;
  final XFile? aadhaarFront;
  final XFile? aadhaarBack;
  final XFile? panCard;
  final String? aadhaarFrontError;
  final String? aadhaarBackError;
  final String? panCardError;

  final VoidCallback onAadhaarFrontCamera;
  final VoidCallback onAadhaarFrontGallery;
  final VoidCallback onAadhaarBackCamera;
  final VoidCallback onAadhaarBackGallery;
  final VoidCallback onPanCardCamera;
  final VoidCallback onPanCardGallery;

  final Function() onUploadAadhaarFront;
  final Function() onUploadAadhaarBack;
  final Function() onDeleteAadhaarFront;
  final Function() onDeleteAadhaarBack;
  final Function() onUploadPanCard;
  final Function() onDeletePanCard;

  const AddressDocumentsSection({
    super.key,
    required this.pincodeCtrl,
    required this.cityCtrl,
    required this.stateCtrl,
    required this.aadhaarCtrl,
    required this.aadhaarFront,
    required this.aadhaarBack,
    required this.panCard,
    this.isCompressingAadhaarFront = false,
    this.isCompressingAadhaarBack = false,
    this.isCompressingPan = false,
    this.isDeletingAadhaarFront = false,
    this.isDeletingAadhaarBack = false,
    this.isDeletingPan = false,
    this.aadhaarFrontError,
    this.aadhaarBackError,
    this.panCardError,
    required this.onAadhaarFrontCamera,
    required this.onAadhaarFrontGallery,
    required this.onAadhaarBackCamera,
    required this.onAadhaarBackGallery,
    required this.onPanCardCamera,
    required this.onPanCardGallery,
    required this.onUploadAadhaarFront,
    required this.onUploadAadhaarBack,
    required this.onDeleteAadhaarFront,
    required this.onDeleteAadhaarBack,
    required this.onUploadPanCard,
    required this.onDeletePanCard,
  });

  @override
  ConsumerState<AddressDocumentsSection> createState() =>
      _AddressDocumentsSectionState();
}

class _AddressDocumentsSectionState
    extends ConsumerState<AddressDocumentsSection> {
  bool isCityEnabled = false;
  bool isStateEnabled = false;

  void _onPincodeChanged(String v) {
    if (v.length == 6) {
      ref.read(pincodeProvider.notifier).fetchPincode(v);
    } else {
      ref.read(pincodeProvider.notifier).clear();
      setState(() {
        isCityEnabled = false;
        isStateEnabled = false;
        widget.cityCtrl.clear();
        widget.stateCtrl.clear();
      });
    }
  }

  void _handlePincodeResponse() {
    ref.listen(pincodeProvider, (previous, next) {
      next.whenOrNull(
        data: (responses) {
          if (responses != null && responses.isNotEmpty) {
            final postOffice = responses[0].postOffice;
            if (postOffice != null && postOffice.isNotEmpty) {
              final firstPostOffice = postOffice[0];
              setState(() {
                widget.cityCtrl.text = firstPostOffice.block ?? "";
                widget.stateCtrl.text = firstPostOffice.state ?? "";
                isCityEnabled = true;
                isStateEnabled = true;
              });
            } else {
              // No recognized pincode
              setState(() {
                isCityEnabled = true;
                isStateEnabled = true;
              });
              CustomSnackBar.show(
                context,
                title: "Opps!",
                message: "Pincode not recognized. Please enter manually.",
                contentType: ContentType.help,
              );
            }
          }
        },
        error: (error, stack) {
          setState(() {
            isCityEnabled = true;
            isStateEnabled = true;
          });
          CustomSnackBar.show(
            context,
            title: "Error",
            message: "Failed to fetch pincode details. Please enter manually.",
            contentType: ContentType.failure,
          );
        },
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    _handlePincodeResponse();
    final pincodeState = ref.watch(pincodeProvider);
    final isPincodeLoading = pincodeState.isLoading;
    final isFrontUploading = ref.watch(
      userProfileProvider.select((val) => val.frontUploadProgress),
    );
    final isBackUploading = ref.watch(
      userProfileProvider.select((val) => val.backUploadProgress),
    );
    final isPanUploading = ref.watch(
      userProfileProvider.select((val) => val.panUploadProgress),
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Address Information",
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        Card(
          color: akWhiteColor,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Pincode",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
                ),
                TextFormField(
                  controller: widget.pincodeCtrl,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  inputFormatters: [
                    // ✅ FIX: ONLY ALLOW NUMBERS - NO LETTERS OR SPECIAL CHARACTERS
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  decoration: _fieldDeco("Pincode").copyWith(
                    suffixIcon: isPincodeLoading
                        ? const Padding(
                            padding: EdgeInsets.all(12.0),
                            child: SizedBox(
                              height: 15,
                              width: 15,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        : null,
                  ),
                  onChanged: _onPincodeChanged,
                  validator: (v) {
                    if (v == null || v.isEmpty) return "Pincode is required";
                    if (v.length != 6) return "Enter valid 6-digit pincode";
                    if (!RegExp(r'^[0-9]+$').hasMatch(v))
                      return "Only numbers are allowed";
                    return null;
                  },
                ),

                const SizedBox(height: 5),
                const Text(
                  "City",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
                ),

                TextFormField(
                  controller: widget.cityCtrl,
                  enabled: isCityEnabled,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.name,
                  textCapitalization: TextCapitalization.words,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
                  ],
                  decoration: _fieldDeco("City").copyWith(
                    hintText: isCityEnabled
                        ? "Enter city name"
                        : "City will be auto-filled",
                    hintStyle: TextStyle(
                      color: isCityEnabled ? Colors.grey : Colors.grey.shade400,
                      fontStyle: isCityEnabled
                          ? FontStyle.normal
                          : FontStyle.italic,
                    ),
                  ),
                  onChanged: (v) {
                    if (v.isNotEmpty) {
                      setState(() => isStateEnabled = true);
                    } else {
                      setState(() {
                        isStateEnabled = false;
                        widget.stateCtrl.clear();
                      });
                    }
                  },
                  validator: (v) {
                    if (!isCityEnabled) return null;
                    if (v == null || v.isEmpty) return "City is required";
                    if (v.length < 2) return "Enter valid city name";
                    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(v))
                      return "Only letters are allowed";
                    return null;
                  },
                ),
                const SizedBox(height: 5),
                const Text(
                  "State",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
                ),
                TextFormField(
                  controller: widget.stateCtrl,
                  enabled: isStateEnabled,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  keyboardType: TextInputType.name,
                  textCapitalization: TextCapitalization.words,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
                  ],
                  decoration: _fieldDeco("State").copyWith(
                    hintText: isStateEnabled
                        ? "Enter state name"
                        : "State will be auto-filled",
                    hintStyle: TextStyle(
                      color: isStateEnabled
                          ? Colors.grey
                          : Colors.grey.shade400,
                      fontStyle: isStateEnabled
                          ? FontStyle.normal
                          : FontStyle.italic,
                    ),
                  ),
                  validator: (v) {
                    if (!isStateEnabled) return null;
                    if (v == null || v.isEmpty) return "State is required";
                    if (v.length < 2) return "Enter valid state name";
                    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(v))
                      return "Only letters are allowed";
                    return null;
                  },
                ),
                const SizedBox(height: 20),

                TextFormField(
                  controller: widget.aadhaarCtrl,
                  keyboardType: TextInputType.number,
                  maxLength: 12,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: _fieldDeco("Aadhaar Number (Optional)"),
                ),

                const SizedBox(height: 25),

                UploadImageWidget(
                  title: "Upload Aadhaar Front Image",
                  file: widget.aadhaarFront,
                  onCamera: widget.onAadhaarFrontCamera,
                  onGallery: widget.onAadhaarFrontGallery,
                  onRemove: widget.onDeleteAadhaarFront,
                  uploadProgress: isFrontUploading,
                  isUploading: isFrontUploading != null,
                  isDeleting: widget.isDeletingAadhaarFront,
                  isCompressing: widget.isCompressingAadhaarFront,
                  errorMessage: widget.aadhaarFrontError,
                ),
                const SizedBox(height: 25),
                UploadImageWidget(
                  title: "Upload Aadhaar Back Image",
                  file: widget.aadhaarBack,
                  onCamera: widget.onAadhaarBackCamera,
                  onGallery: widget.onAadhaarBackGallery,
                  onRemove: widget.onDeleteAadhaarBack,
                  uploadProgress: isBackUploading,
                  isUploading: isBackUploading != null,
                  isDeleting: widget.isDeletingAadhaarBack,
                  isCompressing: widget.isCompressingAadhaarBack,
                  errorMessage: widget.aadhaarBackError,
                ),
                const SizedBox(height: 25),
                UploadImageWidget(
                  title: "Upload PAN Card Image (Mandatory)",
                  file: widget.panCard,
                  onCamera: widget.onPanCardCamera,
                  onGallery: widget.onPanCardGallery,
                  onRemove: widget.onDeletePanCard,
                  uploadProgress: isPanUploading,
                  isUploading: isPanUploading != null,
                  isDeleting: widget.isDeletingPan,
                  isCompressing: widget.isCompressingPan,
                  errorMessage: widget.panCardError,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  InputDecoration _fieldDeco(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: const Color(0xFFF5F5F5),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
    );
  }
}
