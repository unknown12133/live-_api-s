class DeviceDetails {
  final String id;
  final String model;
  const DeviceDetails({required this.id, required this.model});
}
