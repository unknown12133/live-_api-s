class PincodeResponse {
  final String? message;
  final String? status;
  final List<PostOffice>? postOffice;

  PincodeResponse({this.message, this.status, this.postOffice});

  factory PincodeResponse.fromJson(Map<String, dynamic> json) {
    return PincodeResponse(
      message: json['Message'],
      status: json['Status'],
      postOffice: json['PostOffice'] != null
          ? (json['PostOffice'] as List)
                .map((i) => PostOffice.fromJson(i))
                .toList()
          : null,
    );
  }
}

class PostOffice {
  final String? name;
  final String? description;
  final String? branchType;
  final String? deliveryStatus;
  final String? circle;
  final String? district;
  final String? division;
  final String? region;
  final String? block;
  final String? state;
  final String? country;
  final String? pincode;

  PostOffice({
    this.name,
    this.description,
    this.branchType,
    this.deliveryStatus,
    this.circle,
    this.district,
    this.division,
    this.region,
    this.block,
    this.state,
    this.country,
    this.pincode,
  });

  factory PostOffice.fromJson(Map<String, dynamic> json) {
    return PostOffice(
      name: json['Name'],
      description: json['Description'],
      branchType: json['BranchType'],
      deliveryStatus: json['DeliveryStatus'],
      circle: json['Circle'],
      district: json['District'],
      division: json['Division'],
      region: json['Region'],
      block: json['Block'],
      state: json['State'],
      country: json['Country'],
      pincode: json['Pincode'],
    );
  }
}
