import 'dart:convert';
import 'dart:io' as io;
import 'dart:io';
import 'package:animal_kart_demo2/auth/providers/auth_provider.dart';
import 'package:animal_kart_demo2/auth/providers/user_provider.dart';
import 'package:animal_kart_demo2/auth/widgets/register_sections/contact_info_section.dart';
import 'package:animal_kart_demo2/auth/widgets/register_sections/personal_info_section.dart';
import 'package:animal_kart_demo2/auth/widgets/register_sections/address_documents_section.dart';
import 'package:animal_kart_demo2/routes/routes.dart';
import 'package:animal_kart_demo2/utils/app_colors.dart';
import 'package:animal_kart_demo2/utils/styles.dart';
import 'package:animal_kart_demo2/auth/widgets/aadharvalidation_widget.dart';
import 'package:animal_kart_demo2/utils/image_compressor_helper.dart';
import 'package:animal_kart_demo2/utils/save_user.dart';
import 'package:animal_kart_demo2/widgets/floating_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';

class RegisterScreen extends ConsumerStatefulWidget {
  final String phoneNumberFromLogin;

  const RegisterScreen({super.key, required this.phoneNumberFromLogin});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final emailCtrl = TextEditingController();
  final firstNameCtrl = TextEditingController();
  final lastNameCtrl = TextEditingController();
  final occupationCtrl = TextEditingController();
  final dobCtrl = TextEditingController();
  final aadhaarCtrl = TextEditingController();
  final TextEditingController pincodeCtrl = TextEditingController();
  final TextEditingController cityCtrl = TextEditingController();
  final TextEditingController stateCtrl = TextEditingController();

  final emailFocus = FocusNode();
  final firstNameFocus = FocusNode();

  XFile? aadhaarFront;
  XFile? aadhaarBack;
  XFile? panCard;
  String? panCardUrl;
  String gender = "Male";
  DateTime? selectedDOB;
  Map<String, String> aadhaarUrls = {};
  bool _isCompressingAadhaarFront = false;
  bool _isCompressingAadhaarBack = false;
  bool _isCompressingPan = false;
  bool _isDeletingAadhaarFront = false;
  bool _isDeletingAadhaarBack = false;
  bool _isDeletingPan = false;
  String? aadhaarFrontError;
  String? aadhaarBackError;
  String? panCardError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadUserData();
    });
  }

  Future<void> _loadUserData() async {
    final user = await loadUserFromPrefs();

    if (user != null && mounted) {
      setState(() {
        firstNameCtrl.text = user.firstName;
        lastNameCtrl.text = user.lastName;
      });
    }
  }

  @override
  void dispose() {
    emailCtrl.dispose();
    firstNameCtrl.dispose();
    lastNameCtrl.dispose();
    occupationCtrl.dispose();
    dobCtrl.dispose();
    pincodeCtrl.dispose();
    cityCtrl.dispose();
    stateCtrl.dispose();
    aadhaarCtrl.dispose();
    emailFocus.dispose();
    firstNameFocus.dispose();
    super.dispose();
  }

  void clearSelectedDOB() {
    setState(() {
      selectedDOB = null;
    });
  }

  int calculateAge(DateTime birthDate) {
    final today = DateTime.now();
    int age = today.year - birthDate.year;
    if (today.month < birthDate.month ||
        (today.month == birthDate.month && today.day < birthDate.day)) {
      age--;
    }
    return age;
  }

  Future<bool> _checkPermission(Permission permission) async {
    final status = await permission.status;
    if (status.isGranted) {
      return true;
    } else if (status.isDenied) {
      final newStatus = await permission.request();
      return newStatus.isGranted;
    } else if (status.isPermanentlyDenied) {
      if (mounted) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Permission Required'),
            content: Text(
              'This app needs ${permission == Permission.camera ? "Camera" : "Photos"} access to upload documents. Please enable it in settings.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  openAppSettings();
                },
                child: const Text('Settings'),
              ),
            ],
          ),
        );
      }
      return false;
    }
    return false;
  }

  Future<XFile?> pickImage({
    bool compress = true,
    bool isDocument = true,
    Function(bool)? onCompressionStateChanged,
  }) async {
    if (Platform.isIOS) {
      final hasPermission = await _checkPermission(Permission.photos);
      if (!hasPermission) return null;
    }

    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );
    if (picked == null) return null;

    // Compress image if needed
    if (kIsWeb) {
      return picked;
    }
    final file = io.File(picked.path);
    if (compress) {
      if (onCompressionStateChanged != null) onCompressionStateChanged(true);
      try {
        final compressedFile =
            await ImageCompressionHelper.getCompressedImageIfNeeded(
              file,
              maxSizeKB: 250,
              isDocument: isDocument,
            );
        return XFile(compressedFile.path);
      } catch (e) {
        print('Error compressing image: $e');
        return picked;
      } finally {
        if (onCompressionStateChanged != null) onCompressionStateChanged(false);
      }
    }

    return picked;
  }

  Future<XFile?> pickFromCamera({
    bool compress = true,
    bool isDocument = true,
    Function(bool)? onCompressionStateChanged,
  }) async {
    if (Platform.isIOS) {
      final hasPermission = await _checkPermission(Permission.camera);
      if (!hasPermission) return null;
    }

    final picked = await ImagePicker().pickImage(
      source: ImageSource.camera,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );
    if (picked == null) return null;

    if (kIsWeb) return picked;

    final file = io.File(picked.path);

    // Compress image if needed
    if (compress) {
      if (onCompressionStateChanged != null) onCompressionStateChanged(true);
      try {
        final compressedFile =
            await ImageCompressionHelper.getCompressedImageIfNeeded(
              file,
              maxSizeKB: 250,
              isDocument: isDocument,
            );
        return XFile(compressedFile.path);
      } catch (e) {
        print('Error compressing image: $e');
        return picked;
      } finally {
        if (onCompressionStateChanged != null) onCompressionStateChanged(false);
      }
    }

    return picked;
  }

  Future<void> pickAadhaarBackFromCamera() async {
    final file = await pickFromCamera(
      compress: true,
      isDocument: true,
      onCompressionStateChanged: (val) =>
          setState(() => _isCompressingAadhaarBack = val),
    );
    if (file != null && mounted) {
      setState(() {
        aadhaarBack = file;
        aadhaarBackError = null;
      });
      await _uploadAadhaarBack();
    }
  }

  Future<void> pickAadhaarFrontFromGallery() async {
    final file = await pickImage(
      compress: true,
      isDocument: true,
      onCompressionStateChanged: (val) =>
          setState(() => _isCompressingAadhaarFront = val),
    );
    if (file != null && mounted) {
      setState(() {
        aadhaarFront = file;
        aadhaarFrontError = null;
      });
      await _uploadAadhaarFront();
    }
  }

  Future<void> pickAadhaarFrontFromCamera() async {
    final file = await pickFromCamera(
      compress: true,
      isDocument: true,
      onCompressionStateChanged: (val) =>
          setState(() => _isCompressingAadhaarFront = val),
    );
    if (file != null && mounted) {
      setState(() {
        aadhaarFront = file;
        aadhaarFrontError = null;
      });
      await _uploadAadhaarFront();
    }
  }

  Future<void> pickAadhaarBackFromGallery() async {
    final file = await pickImage(
      compress: true,
      isDocument: true,
      onCompressionStateChanged: (val) =>
          setState(() => _isCompressingAadhaarBack = val),
    );
    if (file != null && mounted) {
      setState(() {
        aadhaarBack = file;
        aadhaarBackError = null;
      });
      await _uploadAadhaarBack();
    }
  }

  Future<void> pickPanCardFromCamera() async {
    final file = await pickFromCamera(
      compress: true,
      isDocument: true,
      onCompressionStateChanged: (val) =>
          setState(() => _isCompressingPan = val),
    );
    if (file != null && mounted) {
      setState(() {
        panCard = file;
        panCardError = null;
      });
      await _uploadPanCard();
    }
  }

  Future<void> pickPanCardFromGallery() async {
    final file = await pickImage(
      compress: true,
      isDocument: true,
      onCompressionStateChanged: (val) =>
          setState(() => _isCompressingPan = val),
    );
    if (file != null && mounted) {
      setState(() {
        panCard = file;
        panCardError = null;
      });
      await _uploadPanCard();
    }
  }

  Future<void> selectDOB() async {
    final now = DateTime.now();
    final minYear = now.year - 100;

    final maxYear = now.year - 18;

    int? selectedYear = selectedDOB?.year;
    int? selectedMonth = selectedDOB?.month;
    int? selectedDay = selectedDOB?.day;

    String currentStep = "year";
    if (selectedYear != null && selectedMonth == null) {
      currentStep = "month";
    } else if (selectedYear != null &&
        selectedMonth != null &&
        selectedDay == null) {
      currentStep = "day";
    } else if (selectedYear != null &&
        selectedMonth != null &&
        selectedDay != null) {
      currentStep = "day";
    }

    await showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            final monthNames = [
              "Jan",
              "Feb",
              "Mar",
              "Apr",
              "May",
              "Jun",
              "Jul",
              "Aug",
              "Sep",
              "Oct",
              "Nov",
              "Dec",
            ];

            int daysInMonth = 31;
            if (selectedYear != null && selectedMonth != null) {
              daysInMonth = DateTime(selectedYear!, selectedMonth! + 1, 0).day;
              if (selectedDay != null && selectedDay! > daysInMonth) {
                selectedDay = daysInMonth;
              }
            }

            // Top breadcrumb with weekday
            String topText = "";
            if (selectedYear != null) topText += "$selectedYear";
            if (selectedMonth != null)
              topText += " → ${monthNames[selectedMonth! - 1]}";
            if (selectedDay != null) {
              //final weekday = weekdayNames[DateTime(selectedYear!, selectedMonth!, selectedDay!).weekday - 1];
              topText += " → $selectedDay ";
            }

            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: SizedBox(
                width: 350,
                height: 450,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text(
                        topText.isEmpty ? "Select your Date of Birth" : topText,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                    const Divider(),
                    Expanded(
                      child: currentStep == "year"
                          ? GridView.builder(
                              padding: const EdgeInsets.all(12),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    childAspectRatio: 2.0,
                                    crossAxisSpacing: 6,
                                    mainAxisSpacing: 6,
                                  ),
                              itemCount: maxYear - minYear + 1,
                              itemBuilder: (context, index) {
                                final year = minYear + index;
                                final isSelected = selectedYear == year;
                                return GestureDetector(
                                  onTap: () {
                                    setStateDialog(() {
                                      selectedYear = year;
                                      currentStep = "month";
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? kPrimaryGreen
                                          : Colors.grey.shade200,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      "$year",
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            )
                          : currentStep == "month"
                          ? GridView.builder(
                              padding: const EdgeInsets.all(12),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    childAspectRatio: 2.0,
                                    crossAxisSpacing: 6,
                                    mainAxisSpacing: 6,
                                  ),
                              itemCount: 12,
                              itemBuilder: (context, index) {
                                final month = index + 1;
                                final isSelected = selectedMonth == month;
                                return GestureDetector(
                                  onTap: () {
                                    setStateDialog(() {
                                      selectedMonth = month;
                                      currentStep = "day";
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? kPrimaryGreen
                                          : Colors.grey.shade200,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      monthNames[index],
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            )
                          : GridView.builder(
                              padding: const EdgeInsets.all(12),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 7,
                                    childAspectRatio: 1.2,
                                    crossAxisSpacing: 6,
                                    mainAxisSpacing: 6,
                                  ),
                              itemCount: daysInMonth,
                              itemBuilder: (context, index) {
                                final day = index + 1;
                                final isSelected = selectedDay == day;
                                return GestureDetector(
                                  onTap: () {
                                    setStateDialog(() {
                                      selectedDay = day;
                                    });
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: isSelected
                                          ? kPrimaryGreen
                                          : Colors.grey.shade200,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      "$day",
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          if (currentStep != "year")
                            TextButton(
                              onPressed: () {
                                setStateDialog(() {
                                  if (currentStep == "day")
                                    currentStep = "month";
                                  else if (currentStep == "month")
                                    currentStep = "year";
                                });
                              },
                              child: const Text("Back"),
                            ),
                          const Spacer(),
                          if (currentStep == "day")
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: kPrimaryGreen,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                              onPressed: () {
                                if (selectedYear != null &&
                                    selectedMonth != null &&
                                    selectedDay != null) {
                                  selectedDOB = DateTime(
                                    selectedYear!,
                                    selectedMonth!,
                                    selectedDay!,
                                  );
                                  // final weekday = weekdayNames[selectedDOB!.weekday - 1];
                                  dobCtrl.text =
                                      "${selectedDay.toString().padLeft(2, '0')}-${selectedMonth.toString().padLeft(2, '0')}-${selectedYear}";
                                  Navigator.pop(context);
                                }
                              },
                              child: const Text(
                                "Confirm",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _uploadAadhaarFront() async {
    if (aadhaarFront == null) return;
    try {
      final userId = widget.phoneNumberFromLogin;
      final frontUrl = await ref
          .read(userProfileProvider.notifier)
          .uploadAadhaarFront(file: aadhaarFront!, userId: userId);
      if (frontUrl != null) {
        aadhaarUrls['aadhaar_front_url'] = frontUrl;
      }
    } catch (e) {
      if (mounted)
        FloatingToast.showSimpleToast('Failed to upload front image');
    }
  }

  Future<void> _uploadAadhaarBack() async {
    if (aadhaarBack == null) return;
    try {
      final userId = widget.phoneNumberFromLogin;
      final backUrl = await ref
          .read(userProfileProvider.notifier)
          .uploadAadhaarBack(file: aadhaarBack!, userId: userId);
      if (backUrl != null) {
        aadhaarUrls['aadhaar_back_url'] = backUrl;
      }
    } catch (e) {
      if (mounted) FloatingToast.showSimpleToast('Failed to upload back image');
    }
  }

  Future<void> _deleteAadhaarFront() async {
    setState(() {
      _isDeletingAadhaarFront = true;
      aadhaarFront = null;
      aadhaarFrontError = null;
    });
    aadhaarUrls.remove('aadhaar_front_url');
    try {
      final userId = widget.phoneNumberFromLogin;
      await ref
          .read(userProfileProvider.notifier)
          .deleteAadhaarFront(userId: userId);
    } catch (e) {
      debugPrint('Error deleting front image: $e');
    } finally {
      if (mounted) setState(() => _isDeletingAadhaarFront = false);
    }
  }

  Future<void> _deleteAadhaarBack() async {
    setState(() {
      _isDeletingAadhaarBack = true;
      aadhaarBack = null;
      aadhaarBackError = null;
    });
    aadhaarUrls.remove('aadhaar_back_url');
    try {
      final userId = widget.phoneNumberFromLogin;
      await ref
          .read(userProfileProvider.notifier)
          .deleteAadhaarBack(userId: userId);
    } catch (e) {
      debugPrint('Error deleting back image: $e');
    } finally {
      if (mounted) setState(() => _isDeletingAadhaarBack = false);
    }
  }

  Future<void> _uploadPanCard() async {
    try {
      final userId = widget.phoneNumberFromLogin;
      final url = await ref
          .read(userProfileProvider.notifier)
          .uploadPanCard(file: panCard!, userId: userId);
      if (url != null && mounted) {
        setState(() => panCardUrl = url);
      }
    } catch (e) {
      if (mounted) FloatingToast.showSimpleToast('Failed to upload PAN card');
    }
  }
  Future<void> _deletePanCard() async {
    setState(() {
      _isDeletingPan = true;
      panCard = null;
      panCardUrl = null;
      panCardError = null;
    });
    try {
      final userId = widget.phoneNumberFromLogin;
      await ref
          .read(userProfileProvider.notifier)
          .deletePanCard(userId: userId);
    } catch (e) {
      debugPrint('Error deleting PAN card: $e');
    } finally {
      if (mounted) setState(() => _isDeletingPan = false);
    }
  }
 void submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    // Check if date is selected via picker OR manually entered
    DateTime? dobToUse;

    // First try to use selectedDOB (from date picker)
    if (selectedDOB != null) {
      dobToUse = selectedDOB;
      debugPrint("Using selectedDOB: $selectedDOB");
    }
    // If no selectedDOB, try to parse from manual entry
    else if (dobCtrl.text.trim().isNotEmpty) {
      try {
        final dateText = dobCtrl.text.trim();
        debugPrint("Parsing manual date: '$dateText'");

        final parts = dateText.split('-');
        debugPrint("Date parts: $parts");

        if (parts.length == 3) {
          final day = int.parse(parts[0]);
          final month = int.parse(parts[1]);
          final year = int.parse(parts[2]);

          debugPrint("Parsed - Day: $day, Month: $month, Year: $year");

          // Validate day, month, year ranges
          if (day < 1 || day > 31) {
            FloatingToast.showSimpleToast(
              "Invalid day. Please enter a valid date.",
            );
            return;
          }
          if (month < 1 || month > 12) {
            FloatingToast.showSimpleToast(
              "Invalid month. Please enter a valid date.",
            );
            return;
          }
          if (year < 1900 || year > DateTime.now().year) {
            FloatingToast.showSimpleToast(
              "Invalid year. Please enter a valid date.",
            );
            return;
          }

          dobToUse = DateTime(year, month, day);
          debugPrint("Successfully parsed manual date: $dobToUse");
        } else {
          FloatingToast.showSimpleToast(
            "Please enter date in DD-MM-YYYY format",
          );
          return;
        }
      } catch (e) {
        debugPrint("Error parsing date: $e");
        FloatingToast.showSimpleToast(
          "Please enter a valid date in DD-MM-YYYY format",
        );
        return;
      }
    }

    if (dobToUse == null) {
      FloatingToast.showSimpleToast("Please select your Date of Birth");
      return;
    }

    if (emailCtrl.text.trim().isEmpty) {
      FloatingToast.showSimpleToast("Please enter your email address");
      return;
    }

    int age = calculateAge(dobToUse);
    if (age < 18) {
      FloatingToast.showSimpleToast(
        "You must be at least 18 years old to register",
      );
      return;
    }

    if (aadhaarCtrl.text.trim().isNotEmpty) {
      bool isValid = AadharValidator.validateAadhar(aadhaarCtrl.text.trim());
      if (!isValid) {
        FloatingToast.showSimpleToast("Invalid Aadhaar number");
        return;
      }
    }

    if (panCardUrl == null) {
      setState(() => panCardError = "PAN card is mandatory. Please upload PAN card.");
      FloatingToast.showSimpleToast(
        "PAN card is mandatory. Please upload PAN card.",
      );
      return;
    }

    final auth = ref.read(authProvider.notifier);
    final userId = widget.phoneNumberFromLogin;

    final extraFields = <String, dynamic>{
      'name': '${firstNameCtrl.text} ${lastNameCtrl.text}'.trim(),
      'email': emailCtrl.text.trim(),
      'pincode': pincodeCtrl.text.trim(),
      'city': cityCtrl.text.trim(),
      'state': stateCtrl.text.trim(),
      'occupation': occupationCtrl.text.trim(),
      'isFormFilled': true,
      'gender': gender,
      'dob': dobCtrl.text.trim(),
      'aadhar_number': aadhaarCtrl.text.trim(),
      'first_name': firstNameCtrl.text.trim(),
      "last_name": lastNameCtrl.text.trim(),
      'panCardUrl': panCardUrl,
    };

    if (aadhaarUrls['aadhaar_front_url'] != null) {
      extraFields['aadhar_front_image_url'] = aadhaarUrls['aadhaar_front_url'];
    }
    if (aadhaarUrls['aadhaar_back_url'] != null) {
      extraFields['aadhar_back_image_url'] = aadhaarUrls['aadhaar_back_url'];
    }

    debugPrint("Extra fields: $extraFields");
    debugPrint("Registration Payload: ${jsonEncode(extraFields)}");
    debugPrint("User ID: $userId");

    // API Call
    final user = await auth.updateUserdata(
      userId: userId,
      extraFields: extraFields,
    );

    if (!mounted) return;
    if (user != null) {
      final prefs = await SharedPreferences.getInstance();

      await saveUserToPrefs(user);

      await prefs.setBool('isLoggedIn', true);
      await prefs.setBool('isOtpVerified', true);

      Navigator.pushReplacementNamed(context, AppRouter.home);
    } else {
      FloatingToast.showSimpleToast(
        'Failed to update profile. Please try again.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = ref.watch(authProvider).isLoading;
    final isUploadingDoc = ref.watch(
      userProfileProvider.select((val) => val.isUploading),
    );

    return Scaffold(
      backgroundColor: kFieldBg,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Register Your Account !", style: tsFont24Bold),
                      const SizedBox(height: 6),
                      Text(
                        "Welcome, Please Enter Your Details.",
                        style: tsFont14400,
                      ),
                      const SizedBox(height: 25),

                      ContactInfoSection(
                        emailCtrl: emailCtrl,
                        emailFocus: emailFocus,
                        firstNameFocus: firstNameFocus,
                        formKey: _formKey,
                        phoneNumber: widget.phoneNumberFromLogin,
                      ),
                      const SizedBox(height: 25),

                      PersonalInfoSection(
                        firstNameCtrl: firstNameCtrl,
                        lastNameCtrl: lastNameCtrl,
                        occupationCtrl: occupationCtrl,
                        dobCtrl: dobCtrl,
                        firstNameFocus: firstNameFocus,
                        onSelectDOB: selectDOB,
                        onDOBCleared: clearSelectedDOB,
                        gender: gender,
                        onGenderChanged: (val) => setState(() => gender = val),
                      ),
                      const SizedBox(height: 25),

                      AddressDocumentsSection(
                        pincodeCtrl: pincodeCtrl,
                        cityCtrl: cityCtrl,
                        stateCtrl: stateCtrl,

                        aadhaarCtrl: aadhaarCtrl,
                        aadhaarFront: aadhaarFront,
                        aadhaarBack: aadhaarBack,
                        panCard: panCard,

                        isCompressingAadhaarFront: _isCompressingAadhaarFront,
                        isCompressingAadhaarBack: _isCompressingAadhaarBack,
                        isCompressingPan: _isCompressingPan,
 
                        isDeletingAadhaarFront: _isDeletingAadhaarFront,
                        isDeletingAadhaarBack: _isDeletingAadhaarBack,
                        isDeletingPan: _isDeletingPan,
 
                        aadhaarFrontError: aadhaarFrontError,
                        aadhaarBackError: aadhaarBackError,
                        panCardError: panCardError,
 
                        onAadhaarFrontCamera: pickAadhaarFrontFromCamera,
                        onAadhaarFrontGallery: pickAadhaarFrontFromGallery,
                        onAadhaarBackCamera: pickAadhaarBackFromCamera,
                        onAadhaarBackGallery: pickAadhaarBackFromGallery,
                        onPanCardCamera: pickPanCardFromCamera,
                        onPanCardGallery: pickPanCardFromGallery,

                        onUploadAadhaarFront: _uploadAadhaarFront,
                        onUploadAadhaarBack: _uploadAadhaarBack,
                        onDeleteAadhaarFront: _deleteAadhaarFront,
                        onDeleteAadhaarBack: _deleteAadhaarBack,
                        onUploadPanCard: _uploadPanCard,
                        onDeletePanCard: _deletePanCard,
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Fixed register button at bottom
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: kFieldBg,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: (isLoading || isUploadingDoc) ? null : submitForm,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: (isLoading || isUploadingDoc)
                        ? Colors.grey
                        : kPrimaryGreen,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: isLoading
                      ? const SizedBox(
                          width: 25,
                          height: 25,
                          child: CircularProgressIndicator(
                            strokeWidth: 3,
                            color: Colors.white,
                          ),
                        )
                      : Text("Register", style: tsFont18700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
