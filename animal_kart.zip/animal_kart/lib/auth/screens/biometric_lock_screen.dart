import 'package:flutter/material.dart';
import 'package:animal_kart_demo2/services/biometric_service.dart';
import 'package:animal_kart_demo2/services/secure_storage_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BiometricLockScreen extends StatefulWidget {
  final Widget child;
  const BiometricLockScreen({super.key, required this.child});

  @override
  State<BiometricLockScreen> createState() => _BiometricLockScreenState();
}

class _BiometricLockScreenState extends State<BiometricLockScreen>
    with WidgetsBindingObserver {

  bool _isAuthenticated = false;
  bool _isLoading = true;
  bool _biometricEnabled = false;
  bool _isAuthenticating = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkBiometricAndAuthenticate();
  }

  Future<void> _checkBiometricAndAuthenticate() async {
    final prefs = await SharedPreferences.getInstance();
    final bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
    final bool bioEnabled = await SecureStorageService.isBiometricEnabled();

    setState(() {
      _biometricEnabled = isLoggedIn && bioEnabled;
      _isLoading = false;
    });

    if (!_biometricEnabled) {
      if (mounted) {
        setState(() {
          _isAuthenticated = true;
        });
      }
      return;
    }

    // Force authentication on first app launch
    await _authenticateUser();
  }

  Future<void> _authenticateUser() async {
    if (!_biometricEnabled || _isAuthenticating) {
      if (!_biometricEnabled) {
        setState(() {
          _isAuthenticated = true;
        });
      }
      return;
    }

    _isAuthenticating = true;
    final authenticated = await BiometricService.authenticate();
    _isAuthenticating = false;

    if (mounted) {
      if (authenticated) {
        setState(() {
          _isAuthenticated = true;
        });
      } else {
        setState(() {
          _isAuthenticated = false;
        });
      }
    }
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    debugPrint('App lifecycle state changed to: $state');
    
    // Re-check enabled status and login status every time the app moves
    final prefs = await SharedPreferences.getInstance();
    final bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
    final bool bioEnabled = await SecureStorageService.isBiometricEnabled();
    final bool currentEnabled = isLoggedIn && bioEnabled;

    if (mounted) {
      setState(() {
        _biometricEnabled = currentEnabled;
      });
    }

    if (!currentEnabled) {
      if (!_isAuthenticated) {
        setState(() => _isAuthenticated = true);
      }
      return;
    }

    switch (state) {
      case AppLifecycleState.paused:
        // App is truly in background - lock immediately
        debugPrint('App paused (background) - locking app');
        if (mounted && _isAuthenticated && !_isAuthenticating) {
          setState(() {
            _isAuthenticated = false;
          });
        }
        break;
        
      case AppLifecycleState.resumed:
        // App is coming back to foreground - require authentication
        debugPrint('App resumed (foreground) - requiring authentication');
        if (!_isAuthenticated && !_isAuthenticating) {
          await _authenticateUser();
        }
        break;
        
      case AppLifecycleState.inactive:
        // Don't lock on inactive - this covers notification shade, share dialogs, etc.
        debugPrint('App inactive - NOT locking (covers notifications, share dialogs, control center)');
        break;
        
      case AppLifecycleState.hidden:
        // Don't lock on hidden - this covers app switcher preview
        debugPrint('App hidden - NOT locking (covers app switcher preview)');
        break;
        
      case AppLifecycleState.detached:
        // App is being destroyed - no action needed
        debugPrint('App detached - no action needed');
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Stack(
      children: [
        // Always keep the child (the Navigator) in the tree to preserve its state
        widget.child,

        // Show lock screen overlay if not authenticated
        if (!_isAuthenticated && _biometricEnabled)
          Positioned.fill(
            child: Scaffold(
              backgroundColor: Colors.white,
              body: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.white,
                      Colors.grey.shade50,
                    ],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Branded Logo Container
                    Container(
                      width: 120,
                      height: 120,
                      padding: const EdgeInsets.all(25),
                     
                      child: Image.asset(
                        "assets/images/onboard_logo.png",
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 40),
                    const Text(
                      "App Locked",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),                
                   
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
