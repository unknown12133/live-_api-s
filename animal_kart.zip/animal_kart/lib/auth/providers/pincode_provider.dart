import 'package:animal_kart_demo2/auth/models/pincode_model.dart';
import 'package:animal_kart_demo2/network/api_services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

final pincodeProvider =
    StateNotifierProvider<PincodeNotifier, AsyncValue<List<PincodeResponse>?>>((
      ref,
    ) {
      return PincodeNotifier();
    });

class PincodeNotifier
    extends StateNotifier<AsyncValue<List<PincodeResponse>?>> {
  PincodeNotifier() : super(const AsyncValue.data(null));

  Future<void> fetchPincode(String pincode) async {
    state = const AsyncValue.loading();
    try {
      final result = await ApiServices.fetchPincodeDetails(pincode);
      state = AsyncValue.data(result);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  void clear() {
    state = const AsyncValue.data(null);
  }
}
