import 'package:animal_kart_demo2/profile/providers/profile_provider.dart';
import 'package:animal_kart_demo2/profile/screens/transfer_unit_screen.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/app_constants.dart';
import 'package:animal_kart_demo2/utils/custom_page_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class CoinBadge extends ConsumerWidget {
  const CoinBadge({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileState = ref.watch(profileProvider);
    final coins = profileState.currentUser?.coins ?? 0;

    final bool canNavigate = coins > 0;

    return SizedBox(
      width: double.infinity,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        elevation: 3,
        color: kWhite,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),

          
          onTap: canNavigate
              ? () {
                  Navigator.push(
                    context,
                    RightToLeftPageRoute(child: const TransferUnitScreen()),
                  );
                }
              : null, // ❌ disables tap

          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Image.asset(AppConstants.coinImage, width: 50, height: 50),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Coins", style: tsFont16700),
                    const SizedBox(height: 4),
                    Text(
                      coins.toStringAsFixed(0),
                      style: tsFont18700.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const Spacer(),

                // 🔒 Arrow visual feedback
                Container(
                  height: 28,
                  width: 28,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: canNavigate
                        ? kPrimaryGreen.withOpacity(0.12)
                        : Colors.grey.withOpacity(0.2),
                  ),
                  child: Icon(
                    Icons.arrow_forward_ios,
                    size: 14,
                    color: canNavigate ? kPrimaryGreen : Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
