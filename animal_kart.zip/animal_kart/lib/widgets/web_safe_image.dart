import 'package:flutter/material.dart';
import 'web_safe_image_mobile.dart'
    if (dart.library.js_util) 'web_safe_image_web.dart'
    if (dart.library.html) 'web_safe_image_web.dart'
    as platform_impl;

class WebSafeImage extends StatelessWidget {
  final String imageUrl;
  final double? width;
  final double? height;
  final BoxFit fit;

  const WebSafeImage({
    super.key,
    required this.imageUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: platform_impl.createWebImage(imageUrl, fit),
    );
  }
}
