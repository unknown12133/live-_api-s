import 'package:flutter/material.dart';

Widget createWebImage(String imageUrl, BoxFit fit) {
  return Image.network(
    imageUrl,
    fit: fit,
    errorBuilder: (context, error, stackTrace) {
      return Container(color: Colors.grey[200], child: const Icon(Icons.error));
    },
  );
}
