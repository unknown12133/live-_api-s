import 'package:animal_kart_demo2/auth/models/user_model.dart';
import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/profile/widgets/add_referral_dialog.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ReferBottomSheet extends ConsumerWidget {
  final String referralCode;
  final double unitPrice;
  final double userCoins;
  final UserModel? currentUser;

  const ReferBottomSheet({
    super.key,
    required this.referralCode,
    this.unitPrice = 363000,
    this.userCoins = 0,
    this.currentUser,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final screenHeight = MediaQuery.of(context).size.height;
    final isSmallScreen = screenHeight < 700;
    final bool canRefer = currentUser?.isAbleToRefer ?? false;
    final userRole = currentUser?.role ?? '';
    final isEmployee = userRole.toLowerCase() == 'employee';

    return Padding(
      padding: EdgeInsets.fromLTRB(
        16,
        isSmallScreen ? 8 : 12,
        16,
        isSmallScreen ? 12 : 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          /// Drag Handle
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey.shade400,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          SizedBox(height: isSmallScreen ? 8 : 12),

          /// Scrollable Content
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Title
                  Center(
                    child: Text(
                      context.tr("Refer & Earn"),
                      style: TextStyle(
                        fontSize: isSmallScreen ? 18 : 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),

                  /// Subtitle
                  Center(
                    child: Text(
                      context.tr("Invite friends, earn coins, and convert them into full units."),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: isSmallScreen ? 12 : 14,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ),
                  SizedBox(height: isSmallScreen ? 8 : 12),

                  /// Section Title
                  Text(
                    "How it works",
                    style: TextStyle(
                      fontSize: isSmallScreen ? 14 : 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: isSmallScreen ? 6 : 8),

                  /// Steps - Different content based on user role
                 if (isEmployee) ...[
  _stepCard(
    isSmallScreen,
    icon: Icons.person_add,
    title: "Start Referring",
    description: "As an employee, you can refer friends immediately without making any purchase.",
  ),
  _stepCard(
    isSmallScreen,
    icon: Icons.currency_rupee,
    title: "Earn Coins",
    description: "Earn coins when your referred friends purchase units.",
  ),
  _stepCard(
    isSmallScreen,
    icon: Icons.auto_graph,
    title: "Employee Bonus",
    description: "Receive additional bonus coins for every successful referral.",
  ),
  _stepCard(
    isSmallScreen,
    icon: Icons.swap_horiz,
    title: "Transfer",
    description: "Transfer coins easily by entering basic details.",
  ),
]
 else ...[
                    // Default content for investors
                    _stepCard(
                      isSmallScreen,
                      icon: Icons.shopping_cart,
                      title: "Purchase Unit",
                      description: "Buy a unit and unlock referral rewards.",
                    ),
                    _stepCard(
                      isSmallScreen,
                      icon: Icons.currency_rupee,
                      title: "Earn Coins",
                      description: "Every referral gives coins based on the unit value.",
                    ),
                    _stepCard(
                      isSmallScreen,
                      icon: Icons.auto_graph,
                      title: "Complete Unit",
                      description: "Accumulate coins equal to one unit.",
                    ),
                    _stepCard(
                      isSmallScreen,
                      icon: Icons.swap_horiz,
                      title: "Transfer",
                      description: "Transfer by entering basic details",
                    ),
                  ],
                  
                  SizedBox(height: isSmallScreen ? 8 : 12),
                ],
              ),
            ),
          ),

          /// Fixed Button at the Bottom
         SizedBox(
  width: double.infinity,
  height: isSmallScreen ? 40 : 50,
  child: ElevatedButton(
    onPressed: canRefer
        ? () => _showAddReferralDialog(context)
        : null, // ❌ disabled when false
    style: ElevatedButton.styleFrom(
      backgroundColor:
          canRefer ? kPrimaryDarkColor : Colors.grey.shade400,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30),
      ),
    ),
    child: Text(
      canRefer ? "Add Referral" : "Referral Disabled",
      style: const TextStyle(color: Colors.white, fontSize: 14),
    ),
  ),
),

        ],
      ),
    );
  }

  /// Compact Step Card
  Widget _stepCard(
    bool compact, {
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: compact ? 6 : 10),
      padding: EdgeInsets.symmetric(
        vertical: compact ? 6 : 10,
        horizontal: 12,
      ),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: compact ? 14 : 18,
            backgroundColor: kPrimaryDarkColor.withValues(alpha:0.12),
            child: Icon(
              icon,
              size: compact ? 14 : 18,
              color: kPrimaryDarkColor,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: compact ? 12 : 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: compact ? 11 : 13,
                    color: Colors.grey.shade700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showAddReferralDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AddReferralDialog(
        referedByMobile: currentUser!.mobile,
        referedByName: "${currentUser!.firstName} ${currentUser!.lastName}",
        onSuccess: () {
          Navigator.of(context).pop();
        },
      ),
    );
  }
}
