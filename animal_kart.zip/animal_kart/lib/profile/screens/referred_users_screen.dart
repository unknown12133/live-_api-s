import 'package:animal_kart_demo2/profile/models/refferal_user_state.dart';
import 'package:animal_kart_demo2/profile/providers/refferal_provider.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/widgets/Shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ReferralUsersScreen extends ConsumerStatefulWidget {
  final String mobile;

  const ReferralUsersScreen({super.key, required this.mobile});

  @override
  ConsumerState<ReferralUsersScreen> createState() =>
      _ReferralUsersScreenState();
}

class _ReferralUsersScreenState extends ConsumerState<ReferralUsersScreen>
    with TickerProviderStateMixin {
  /// stores expand / collapse state per card
  List<bool> _expanded = [];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(refferalUserProvider.notifier).fetchUsersByMobile(widget.mobile);
    });
  }

  Future<void> _refresh() async {
    await ref
        .read(refferalUserProvider.notifier)
        .fetchUsersByMobile(widget.mobile);
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(refferalUserProvider);
    final double screenWidth = MediaQuery.of(context).size.width;
    final double avatarRadius = screenWidth * 0.065;
    // final double iconSize = MediaQuery.of(context).size.width * 0.020;
    // final double titleGap = iconSize * 0.0001;

    /// initialize expand list when data arrives
    if (state.userResponse != null &&
        _expanded.length != state.userResponse!.refferalUsers.length) {
      _expanded = List.generate(
        state.userResponse!.refferalUsers.length,
        (_) => false,
      );
    }

    return Scaffold(
      backgroundColor: kScreenBg,
      appBar: AppBar(
        backgroundColor: kPrimaryGreen,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'Referral Users',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        //centerTitle: true,
      ),

      body: RefreshIndicator(
        onRefresh: _refresh,
        child: _buildBody(state, avatarRadius),
      ),
    );
  }

  // Widget _buildBody(RefferalUserState state) {
  Widget _buildBody(RefferalUserState state, double avatarRadius) {
    if (state.isLoading) {
      return ordersShimmerList();
    }

    if (state.userResponse == null ||
        state.userResponse!.refferalUsers.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.group_outlined, size: 80, color: Colors.grey.shade400),

              const SizedBox(height: 20),

              Text(
                'No referrals yet',
                style: tsFont20700_Gotham.copyWith(color: kTextPrimary),
              ),

              const SizedBox(height: 8),

              Text(
                'Invite your friends and start earning rewards when they join.',
                textAlign: TextAlign.center,
                style: tsFont14600M.copyWith(
                  color: kTextSecondary,
                  height: 1.4,
                ),
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(15),
      itemCount: state.userResponse!.refferalUsers.length,
      itemBuilder: (context, index) {
        final user = state.userResponse!.refferalUsers[index];

        return Padding(
          padding: const EdgeInsets.only(bottom: 10, top: 5),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: .06),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// HEADER (CLICK TO EXPAND / COLLAPSE)
                InkWell(
                  onTap: () {
                    setState(() {
                      _expanded[index] = !_expanded[index];
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 12,
                    ),

                    child: Row(
                      children: [
                        // Profile Circle Avatar
                        CircleAvatar(
                          // radius: 25,
                          radius: avatarRadius,
                          backgroundColor: akForestWhisper,

                          // backgroundColor: Colors.blue.shade100,
                          child: Text(
                            user.fullName.isNotEmpty
                                ? user.fullName[0].toUpperCase()
                                : 'U',
                            style: tsFont24500.copyWith(
                              color: Colors.white,

                              // color: Colors.blue.shade700,
                              fontSize: avatarRadius * 0.9,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        // Name and Mobile
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                user.fullName.isEmpty
                                    ? 'Unknown User'
                                    : user.fullName,
                                style: tsFont16700N.copyWith(
                                  fontWeight: FontWeight.w200,
                                  color: kTextPrimary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  const Text('Mobile Number :'),
                                  const SizedBox(width: 4),
                                  Text(
                                    user.mobile,
                                    style: tsFont14600M.copyWith(
                                      fontWeight: FontWeight.w200,
                                      color: kTextPrimary,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        Icon(
                          _expanded[index]
                              ? Icons.keyboard_arrow_up
                              : Icons.keyboard_arrow_down,
                        ),
                      ],
                    ),
                  ),
                ),

                /// EXPANDABLE CONTENT
                AnimatedSize(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                  child: _expanded[index]
                      ? Column(
                          children: [
                            _divider(),

                            // Stats Section
                            Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                children: [
                                  _buildStatRow(
                                    'Total Orders',
                                    user.totalOrders.toString(),
                                  ),
                                  const SizedBox(height: 8),
                                  _buildStatRow(
                                    'Total Paid Units',
                                    user.paidUnit.toString(),
                                  ),
                                  const SizedBox(height: 8),
                                  _buildStatRow(
                                    'Total Paid Orders',
                                    user.paidCount.toString(),
                                  ),
                                  const SizedBox(height: 8),
                                  // _buildStatRow(
                                  //   'Total Pending Payment',
                                  //   user.pendingPaymentCount.toString(),
                                  // ),
                                  // const SizedBox(height: 8),
                                  // _buildStatRow(
                                  //   'Total Pending Verification',
                                  //   user.pendingAdminVerificationCount
                                  //       .toString(),
                                  // ),
                                 // const SizedBox(height: 8),
                                  // _buildStatRow(
                                  //   'Total Rejected Orders',
                                  //   user.rejectedCount.toString(),
                                  // ),
                                ],
                              ),
                            ),

                            _divider(),

                            // Coins Section
                            Padding(
                              padding: const EdgeInsets.all(14),
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: kPrimaryDarkColor),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Coins Earned',
                                            style: tsFont13800.copyWith(
                                              fontSize: 14,
                                              color: kTextPrimary,
                                              fontWeight: FontWeight.w300,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            '${user.totalCoinsEarnedFromThisUser.toInt()} Coins',
                                            style: tsFont17700a.copyWith(
                                              fontWeight: FontWeight.w700,
                                              color: Colors.amber.shade700,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatRow(String label, String value) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: tsFont14400.copyWith(
              fontWeight: FontWeight.w700,
              color: kTextPrimary,
            ),
          ),
        ),
        Text(
          value,
          style: tsFont14400.copyWith(
            fontWeight: FontWeight.bold,
            color: kTextPrimary,
          ),
        ),
      ],
    );
  }

  Widget _divider() {
    return Container(
      height: 1,
      width: double.infinity,
      color: Colors.grey.withValues(alpha: 0.7),
    );
  }
}
