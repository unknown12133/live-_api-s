import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/widgets/Shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:animal_kart_demo2/utils/app_constants.dart';

import '../models/coins_model.dart';
import '../providers/coin_provider.dart';

class TransferUnitScreen extends ConsumerWidget {
  const TransferUnitScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final coinAsync = ref.watch(coinProvider);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: kPrimaryGreen,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          context.tr('Wallet'),
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        //centerTitle: true,
      ),
      backgroundColor: kWhite,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: RefreshIndicator(
            onRefresh: () => ref.refresh(coinProvider.future),
            child: coinAsync.when(
              loading: () => Center(child: ordersShimmerList()),
              error: (e, _) => CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverFillRemaining(child: Center(child: Text(e.toString()))),
                ],
              ),
              data: (response) {
                final transactions = response?.transactions ?? [];
                final totalCoins = response?.totalCoins ?? 0.0;

                return CustomScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 14),

                          /// HEADER
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      context.tr('coins'),
                                      style: tsFont16400,
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      _formatAmount(totalCoins),
                                      style: tsFont36Bold.copyWith(
                                        color: kTextPrimary,
                                        fontSize: 40,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    Text(
                                      context.tr(
                                        'Earn and spend coins to unlock purchase units, enabling you to invest in buffaloes.',
                                        //'Spend coins to unlock your Buffalo! Purchase 1 unit today and get free CPF for an entire year.',
                                      ),
                                      style: tsFont14400.copyWith(
                                        height: 1.5,
                                        color: kTextPrimary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Image.asset(
                                AppConstants.coinDetailsImage,
                                width: 90,
                                height: 90,
                              ),
                            ],
                          ),

                          const SizedBox(height: 8),
                          const Divider(),

                          /// ONLY EARNINGS (NO SPENDS)
                          _StatItem(
                            title: context.tr("lifetime earnings"),
                            value: _formatAmount(totalCoins),
                          ),

                          const Divider(),
                          const SizedBox(height: 18),

                          Text(
                            context.tr("COIN LEDGER"),
                            style: tsFont13900.copyWith(
                              letterSpacing: 2,
                              fontWeight: FontWeight.w600,
                              color: kTextPrimary,
                            ),
                          ),

                          const SizedBox(height: 16),
                        ],
                      ),
                    ),

                    /// LEDGER LIST
                    if (transactions.isEmpty)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.account_balance_wallet_outlined,
                                size: 48,
                                color: kTextSecondary.withOpacity(0.5),
                              ),
                              SizedBox(height: 12),
                              Text(
                                context.tr("No coins are available yet"),
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black45,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      SliverList.builder(
                        itemCount: transactions.length,
                        itemBuilder: (context, index) {
                          final txn = transactions[index].transaction;

                          return CoinLedgerItem(
                            amount: _formatAmount(txn.coins),
                            label: _buildLabel(txn),
                            date: _formatDate(txn.createdAt),
                            isDebit: txn.coins < 0,
                          );
                        },
                      ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

/// STAT ITEM
class _StatItem extends StatelessWidget {
  final String title;
  final String value;

  const _StatItem({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: tsFont22700.copyWith(
            fontWeight: FontWeight.bold,
            color: kTextPrimary,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          style: tsFont13900.copyWith(
            color: kTextSecondary,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}

/// LEDGER ITEM (ALWAYS CREDIT)
class CoinLedgerItem extends StatelessWidget {
  final String amount;
  final String label;
  final String date;
  final bool isDebit;

  const CoinLedgerItem({
    super.key,
    required this.amount,
    required this.label,
    required this.date,
    this.isDebit = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// FIXED ICON BOX (will NEVER resize)
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(7),
              border: Border.all(color: isDebit ? Colors.red : Colors.green),
            ),
            child: Center(
              child: Icon(
                isDebit ? Icons.south_west : Icons.north_east,
                size: 16,
                color: isDebit ? Colors.red : Colors.green,
              ),
            ),
          ),

          const SizedBox(width: 14),

          /// TEXT CONTENT
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// Amount + Date
                Row(
                  children: [
                    Text(
                      amount,
                      style: tsFont18700.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const Spacer(),
                    Text(
                      date,
                      style: tsFont12400.copyWith(
                        color: kTextSecondary.withOpacity(0.7),
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 4),

                /// MULTI-LINE LABEL (wraps properly)
                Text(
                  label,
                  style: tsFont14400.copyWith(
                    fontSize: 13,
                    color: kTextPrimary,
                  ),
                  softWrap: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// HELPERS

String _buildLabel(CoinTransaction txn) {
  if (txn.coins < 0) {
    // 1. For decreasing icon (Debits) -> show just the description
    return txn.description != null && txn.description!.trim().isNotEmpty
        ? txn.description!.trim()
        : 'Redeemed against Order';
  } else {
    // 2. For increasing icon (Credits) -> show referral name and units
    final name = txn.name.isNotEmpty
        ? txn.name
        : (txn.giverName != null && txn.giverName!.isNotEmpty
              ? txn.giverName!
              : 'User');

    final units = txn.noOfUnitsBuy != null && txn.noOfUnitsBuy! > 0
        ? txn.noOfUnitsBuy!.toInt()
        : 1;

    return 'Referred $name purchased $units unit';
  }
}

String _formatAmount(double value) {
  return value
      .toStringAsFixed(0)
      .replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
}

String _formatDate(String date) {
  try {
    // API format: dd-MM-yyyy
    final parts = date.split('-');

    final day = parts[0];
    final month = parts[1];
    final year = parts[2];

    const months = {
      '01': 'JAN',
      '02': 'FEB',
      '03': 'MAR',
      '04': 'APR',
      '05': 'MAY',
      '06': 'JUN',
      '07': 'JUL',
      '08': 'AUG',
      '09': 'SEP',
      '10': 'OCT',
      '11': 'NOV',
      '12': 'DEC',
    };

    return '$day ${months[month]} $year';
  } catch (_) {
    return date;
  }
}
