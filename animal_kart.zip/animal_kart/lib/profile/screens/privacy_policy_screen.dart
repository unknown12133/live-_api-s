import 'package:animal_kart_demo2/utils/app_colors.dart';
import 'package:animal_kart_demo2/utils/styles.dart';
import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kWhite,
      appBar: AppBar(
        backgroundColor: kPrimaryGreen,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Privacy Policy',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
       // centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Your Privacy Matters', style: tsFont18700_Gotham),
            const SizedBox(height: 16),
            Text(
              'This Privacy Policy explains how Animal Kart collects, uses, and protects your information.',
              style: tsFont16400,
            ),
            const SizedBox(height: 24),
            _buildSection(
              '1. Information We Collect',
              'We collect information you provide directly to us, such as when you create an account, list an animal, or contact support. This may include your name, mobile number, and location.',
            ),
            _buildSection(
              '2. How We Use Your Information',
              'We use your information to operate and improve our services, facilitate connections between buyers and sellers, and communicate with you about updates and promotions.',
            ),
            _buildSection(
              '3. Data Security',
              'We implement reasonable security measures to protect your personal information. However, no method of transmission over the internet is 100% secure.',
            ),
            _buildSection(
              '4. Biometric Information',
              'If you use biometric login (fingerprint), this data is processed locally on your device using secure hardware elements. Animal Kart does not collect or store your biometric data on our servers.',
            ),
            _buildSection(
              '5. Sharing of Information',
              'We do not sell your personal information. We may share information with service providers who help us operate our business, or as required by law.',
            ),
            _buildSection(
              '6. Contact Us',
              'If you have any questions about this Privacy Policy, please contact our support team.',
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                'Last Updated: January 2026',
                style: tsFont14400.copyWith(color: kTextSecondary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: tsFont16700),
          const SizedBox(height: 8),
          Text(content, style: tsFont14400_Black),
        ],
      ),
    );
  }
}
