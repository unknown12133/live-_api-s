import 'package:animal_kart_demo2/utils/app_colors.dart';
import 'package:animal_kart_demo2/utils/styles.dart';
import 'package:flutter/material.dart';

class TermsOfServiceScreen extends StatelessWidget {
  const TermsOfServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kWhite,
      appBar: AppBar(
        backgroundColor: kPrimaryGreen,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Terms & Conditions',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        //centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Welcome to AnimalKart', style: tsFont18700_Gotham),
            const SizedBox(height: 16),
            Text(
              'By installing, registering, or using the AnimalKart mobile application, you agree to the Privacy Policy and Terms & Conditions outlined below.',
              style: tsFont16400,
            ),
            const SizedBox(height: 24),

            Text('Privacy Policy', style: tsFont18700_Gotham),
            const SizedBox(height: 16),

            _buildSection(
              '1. Information We Collect',
              '• Personal Identity Information: Name, gender, email address.\n'
                  '• Contact Information: Registered mobile number for login and OTP verification.\n'
                  '• Financial & Transaction Data: Manual payment details (UTR, bank name, IFSC), payment proofs, order history, total investment values.\n'
                  '• Referral Data: Information regarding successful referrals and accumulated referral coins.',
            ),

            _buildSection(
              '2. How We Use Your Information',
              '• Account Management: Verify identity via OTP and manage profile.\n'
                  '• Transaction Processing: Verify manual payments and provide invoices for "Paid" orders.\n'
                  '• Investment Projections: Display personalized income projections and milk production.\n'
                  '• Rewards Program: Credit Referral reward coins are credited to your AnimalKart account.\n'
                  '• Communication: Notify regarding payment verification and order status.',
            ),

            _buildSection(
              '3. Data Storage and Security',
              '• Secure Storage: Manual payment data and transaction proofs stored securely.\n'
                  '• Biometric Security: Optional "App Lock" via fingerprint for local authentication.\n'
                  '• Admin Access: Only authorized Admin and Management teams can verify payments and manage rules.',
            ),

            _buildSection(
              '4. Information Sharing and Disclosure',
              '• Insurance Partners: For optional insurance coverage of buffalo units.\n'
                  '• Admin/Verification Teams: To review submitted manual payments (typically 3 business days).\n'
                  '• Third-Party Sharing: Referral links shared via WhatsApp, SMS, or Email only at user direction.',
            ),

            _buildSection(
              '5. Data Retention and User Rights',
              '• Read-Only Records: Verified orders/payments remain read-only.\n'
                  '• Coin Management: You can redeem your referral coins directly within the app.\n'
                  '• Account Control: Users can log out anytime, redirected to login screen.',
            ),

            _buildSection(
              '6. Updates to This Policy',
              'The policy may be updated as AnimalKart evolves. Continued use indicates acceptance of updated terms.',
            ),

            const SizedBox(height: 24),
            Text('Terms & Conditions', style: tsFont18700_Gotham),
            const SizedBox(height: 16),

            _buildSection(
              '1. Unit Purchase',
              '• One unit = 2 buffaloes + 2 calves.\n'
                  '• Total investment = Unit price.\n'
                  '• Asset value and milk revenue projections are indicative (10-year estimates).\n'
                  '• Expected revenue break-even period is approximately 42 months, enabling faster capital recovery.\n'
                  '• Income is protected through the Cattle Protection Fund (CPF), providing a structured income safety mechanism.\n'
                  '• CPF safeguards livestock against unforeseen risks, reducing revenue volatility.\n'
                  '• This protection ensures continuity of income and supports steady asset appreciation over time.',
            ),

            _buildSection(
              '2. Referral Program & Coin Conversion',
              '• Coins earned only via successful referrals who complete a purchase.\n'
                  '• Reward Rate: Based on referred user purchase.\n'
                  '• 1 Coin = ₹1 within app, coins non-transferable/non-withdrawable.',
            ),

            _buildSection(
              '3. Coin-Based Purchases and Gifting',
              '• Coins can be used for purchases within the app.\n'
                  '• Purchased units can be gifted to another person once balance requirement is met.',
            ),

            _buildSection(
              '4. Payment and Verification',
              '• All manual payments verified by Admin before status changes to "Paid".\n'
                  '• Verification typically takes 3 business days.\n'
                  '• Invoices generated only after payment verification.',
            ),

            _buildSection(
              '5. KYC & Government Identification Data',
              '• Aadhaar & PAN collected strictly for identity verification and regulatory compliance.\n'
                  '• Aadhaar biometric info is not collected or stored.\n'
                  '• Data securely encrypted, accessed only by authorized personnel.',
            ),

            _buildSection(
              '6. User Consent',
              'By installing and using AnimalKart, users consent to the collection, storage, and usage of their personal information as described.',
            ),

            _buildSection(
              '7. Third-Party Data Sharing',
              '• Personal data is never sold, rented, or traded.\n'
                  '• Shared only with essential service partners for operational purposes.',
            ),

            _buildSection(
              '8. Data Deletion & Account Removal',
              'Users may request account deletion via support@animalkart.in. Certain financial/transactional records may be retained as per law.',
            ),

            _buildSection(
              '9. Risk & Return Disclaimer',
              'All investment values, Monthly revenue figures, income projections, and asset appreciation details are indicative estimates only and do not guarantee returns.',
            ),

            const SizedBox(height: 20),
            Center(
              child: Text(
                'Last Updated: January 2026',
                style: tsFont14400.copyWith(color: kTextSecondary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: tsFont16700),
          const SizedBox(height: 8),
          Text(content, style: tsFont14400_Black),
        ],
      ),
    );
  }
}
