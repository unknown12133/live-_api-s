class CoinTransactionResponse {
  final List<CoinTransactionItem> transactions;
  final double totalCoins;

  CoinTransactionResponse({
    required this.transactions,
    required this.totalCoins,
  });

  factory CoinTransactionResponse.fromJson(Map<String, dynamic> json) {
    final list = json['transactions'];

    return CoinTransactionResponse(
      transactions: list == null
          ? []
          : (list as List).map((e) => CoinTransactionItem.fromJson(e)).toList(),
      totalCoins: (json['totalcoins'] ?? 0).toDouble(),
    );
  }
}

class CoinTransactionItem {
  final CoinTransaction transaction;

  CoinTransactionItem({required this.transaction});

  factory CoinTransactionItem.fromJson(Map<String, dynamic> json) {
    return CoinTransactionItem(
      transaction: json['transaction'] == null
          ? CoinTransaction.empty()
          : CoinTransaction.fromJson(json['transaction']),
    );
  }
}

class CoinTransaction {
  final double coins;
  final String createdAt;
  final String name;

  final double? noOfUnitsBuy;
  final String? giverName;
  final String? description;
  final String? type;

  CoinTransaction({
    required this.coins,
    required this.createdAt,
    required this.name,
    this.noOfUnitsBuy,
    this.giverName,
    this.description,
    this.type,
  });

  factory CoinTransaction.empty() {
    return CoinTransaction(coins: 0, createdAt: '', name: '');
  }

  factory CoinTransaction.fromJson(Map<String, dynamic> json) {
    return CoinTransaction(
      coins: (json['coins'] ?? 0).toDouble(),
      createdAt: json['created_at'] ?? '',
      name: json['name'] ?? '',
      noOfUnitsBuy: (json['no_of_units_buy'] as num?)?.toDouble() ?? 0.0,
      giverName: json['giverName'],
      description: json['description'],
      type: json['type'],
    );
  }
}
