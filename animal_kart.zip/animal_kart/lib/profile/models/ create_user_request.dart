class CreateUserRequest {
  final String firstName;
  final String lastName;
  final String mobile;
  final String referralCode;

  CreateUserRequest({
    required this.firstName,
    required this.lastName,
    required this.mobile,
    required this.referralCode,
  });

  Map<String, dynamic> toJson() {
    return {
      'mobile': mobile,
      'first_name': firstName,
      'last_name': lastName,
      'referral_code': referralCode,
    };
  }
}
