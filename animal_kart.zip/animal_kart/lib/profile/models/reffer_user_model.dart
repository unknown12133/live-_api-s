// models/user_model.dart

class RefferalUserResponse {
  final int statuscode;
  final String status;
  final List<RefUsers> refferalUsers;

  RefferalUserResponse({
    required this.statuscode,
    required this.status,
    required this.refferalUsers,
  });

  factory RefferalUserResponse.fromJson(Map<String, dynamic> json) {
    return RefferalUserResponse(
      statuscode: json['statuscode'] ?? 0,
      status: json['status'] ?? '',
      refferalUsers: (json['users'] as List<dynamic>?)
              ?.map((user) => RefUsers.fromJson(user))
              .toList() ??
          [],
    );
  }
}

class RefUsers {
  final String firstName;
  final String lastName;
  final String mobile;
  final String name; 
  final int totalOrders;
  final int paidCount;
  final int pendingPaymentCount;
  final int pendingAdminVerificationCount;
  final int rejectedCount;
  final double paidUnit;
  final double totalCoinsEarnedFromThisUser; 

  RefUsers({
    required this.firstName,
    required this.lastName,
    required this.mobile,
    required this.name,
    required this.totalOrders,
    required this.paidCount,
    required this.pendingPaymentCount,
    required this.pendingAdminVerificationCount,
    required this.rejectedCount,
    required this.totalCoinsEarnedFromThisUser,
    required this.paidUnit,
  });

  factory RefUsers.fromJson(Map<String, dynamic> json) {
    return RefUsers(
      firstName: json['first_name'] as String? ?? '',
      lastName: json['last_name'] as String? ?? '',
      mobile: json['mobile'] as String? ?? '',
      name: json['name'] as String? ?? '', 
      totalOrders: (json['total_orders'] as num?)?.toInt() ?? 0,
      paidCount: (json['paid_count'] as num?)?.toInt() ?? 0,
      pendingPaymentCount: (json['pending_payment_count'] as num?)?.toInt() ?? 0,
      pendingAdminVerificationCount: (json['pending_admin_verification_count'] as num?)?.toInt() ?? 0,
      rejectedCount: (json['rejected_count'] as num?)?.toInt() ?? 0,
      totalCoinsEarnedFromThisUser: (json['total_coins_earned_from_this_user'] as num?)?.toDouble() ?? 0.0,
      paidUnit: (json['paid_units'] as num?)?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'first_name': firstName,
      'last_name': lastName,
      'mobile': mobile,
      'name': name,
      'total_orders': totalOrders,
      'paid_count': paidCount,
      'pending_payment_count': pendingPaymentCount,
      'pending_admin_verification_count': pendingAdminVerificationCount,
      'rejected_count': rejectedCount,
      'total_coins_earned_from_this_user': totalCoinsEarnedFromThisUser,
      'paid_units': paidUnit
    };
  }


  String get fullName => name.isNotEmpty ? name : '$firstName $lastName';
}