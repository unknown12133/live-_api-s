import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:flutter/material.dart';

import '../../orders/widgets/custom_widgets.dart';

class QuantitySelector extends StatelessWidget {
  final int quantity;
  final Function(int) onQuantityChanged;
  final int buffaloPrice;
  final double units;
  final String unitText;

  const QuantitySelector({
    super.key,
    required this.quantity,
    required this.onQuantityChanged,
    required this.buffaloPrice,
    required this.units,
    required this.unitText,
  });

  @override
Widget build(BuildContext context) {
  final totalBuffaloes = quantity * 2;
  final totalCalves = quantity * 2;
  final totalPrice = buffaloPrice * totalBuffaloes;

  final size = MediaQuery.of(context).size;
  final isSmallScreen = size.width < 360;

  return Column(
    children: [

      /// 🔹 BLOCK 1 : Quantity Selector
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kPrimaryGreen, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: kTextSecondary.withOpacity(0.1),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(context.tr("selectQuantity"), style: tsFont16700),
                Text(
                  context.tr("maxBuffaloes"),
                  style: tsFont12400.copyWith(color: kTextSecondary),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${context.tr("Quantity")}: $quantity",
                    style: tsFont14600.copyWith(fontSize: 15),
                    ),
                  const SizedBox(height: 4),
                    Text(
                    "$totalBuffaloes ${totalBuffaloes == 1 ? context.tr("buffalo") : context.tr("buffaloes")}, "
                    "$totalCalves ${totalCalves == 1 ? context.tr("calf") : context.tr("calves")}",
                      style: tsFont14600,
                    ),
                  const SizedBox(height: 4),
                    Text(
                      "${units.toInt()} $unitText",
                      style: tsFont16700.copyWith(
                      fontSize: 17,
                        color: kPrimaryGreen,
                      letterSpacing: 0.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3F5F2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                  mainAxisSize: MainAxisSize.min,
                    children: [
                      GestureDetector(
                        onTap: quantity > 1
                            ? () => onQuantityChanged(quantity - 1)
                            : null,
                        child: CircleAvatar(
                          radius: 12,
                        backgroundColor: quantity > 1
                            ? Colors.black
                            : Colors.grey.shade400,
                        child: const Icon(
                          Icons.remove,
                          size: 18,
                          color: Colors.white,
                        ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Text("$quantity", style: tsFont16700),
                      const SizedBox(width: 16),
                      GestureDetector(
                      onTap: quantity < 999
                          ? () => onQuantityChanged(quantity + 1)
                          : null,
                      child: CircleAvatar(
                          radius: 12,
                        backgroundColor: quantity < 999
                            ? Colors.black
                            : Colors.grey.shade400,
                        child: const Icon(
                          Icons.add,
                          size: 18,
                          color: Colors.white,
                        ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          //  Row(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: [
          //     Text(
          //       '* ',
          //       style: TextStyle(
          //         fontSize: 13,
          //         fontWeight: FontWeight.w600,
          //         color: kPrimaryGreen,
          //         height: 1.4,
          //       ),
          //     ),
          //     Expanded(
          //       child: RichText(
          //         text: TextSpan(
          //           style: TextStyle(
          //             fontSize: 13,
          //             fontWeight: FontWeight.w500,
          //             color: Colors.grey.shade700,
          //             height: 1.4,
          //           ),
          //           children: [
          //             TextSpan(text: 'Free '),
          //             TextSpan(
          //               text: '1-year CPF coverage',
          //               style: TextStyle(
          //                 fontWeight: FontWeight.w700,
          //                 color: kPrimaryGreen,
          //               ),
          //             ),
          //             TextSpan(text: ' for 2nd buffalo with each unit'),
          //           ],
          //         ),
          //       ),
          //     ),
          //   ],
          // ),
          const SizedBox(height: 5),
            const Divider(),
          const SizedBox(height: 8),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
               Text(
                "${context.tr("buffaloPrice")} :",
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                "${FormatUtils.formatAmountWithCurrency(buffaloPrice * 1)}", // Multiply by 2 here
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              ],
            ),
            
          ],
        ),
      ),

     
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xFFDFF7ED),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                context.tr("grandTotal"),
                style: (isSmallScreen ? tsFont14700 : tsFont16700)
                    .copyWith(fontWeight: FontWeight.w700),
              ),
            ),
            Text(
              FormatUtils.formatAmountWithCurrency(totalPrice),
              style: (isSmallScreen ? tsFont14700 : tsFont16700)
                  .copyWith(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    ],
  );
}
}