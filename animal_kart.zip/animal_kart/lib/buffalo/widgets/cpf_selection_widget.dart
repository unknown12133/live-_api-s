import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:flutter/material.dart';

import '../../orders/widgets/custom_widgets.dart';

class CpfSelectionWidget extends StatelessWidget {
  final dynamic buffalo;
  final int quantity;
  final bool isCpfSelected;
  final double units;
  final String unitText;
  final int cpfUnitsToPay;
  final int freeCpfUnits;
  final int buffaloPrice;
  final int cpfAmount;
  final int totalAmount;
  final Function(bool) onCpfSelectionChanged;

  const CpfSelectionWidget({
    super.key,
    required this.buffalo,
    required this.quantity,
    required this.isCpfSelected,
    required this.units,
    required this.unitText,
    required this.cpfUnitsToPay,
    required this.freeCpfUnits,
    required this.buffaloPrice,
    required this.cpfAmount,
    required this.totalAmount,
    required this.onCpfSelectionChanged,
  });

  @override
  Widget build(BuildContext context) {
    final cpfPerBuffalo = buffalo.insurance;

    return Column(
      children: [
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFE8F8FF),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Checkbox(value: isCpfSelected, onChanged: null),
                  const SizedBox(width: 8),
                  Text(
                    context.tr("includeCpf"),
                    style: tsFont16700.copyWith(
                      color: isCpfSelected ? kTextPrimary : kTextSecondary,
                    ),
                  ),
                ],
              ),

              if (isCpfSelected) ...[
                const SizedBox(height: 8),
                const Divider(),
                const SizedBox(height: 8),
                
                _buildCpfDetailRow(
  context.tr("totalBuffaloes"),
                
                  "${quantity * 2} ${quantity * 2 == 1 ? context.tr("buffalo") : context.tr("buffaloes")}",
),

                // _buildCpfDetailRow(
                //   context.tr("totalBuffaloes"),
                //   "$quantity  ${quantity == 1 
                //     ? context.tr("buffalo") 
                //     : context.tr("buffaloes")}",
                // ),
                _buildCpfDetailRow(
                  context.tr("units"),
                  units.toInt().toString(),
                ),
_buildCpfDetailRow(
  "${context.tr("Free CPF discount")} "
    // "($freeCpfUnits ${freeCpfUnits == 1 ? 'unit' : 'units'})",
    //               "- ₹${freeCpfUnits * cpfPerBuffalo}",
                      "(${quantity} ${quantity == 1 ? 'unit' : 'units'})",
                  "- ${FormatUtils.formatAmountWithCurrency(quantity * cpfPerBuffalo)}", // Free CPF amount = 1 CPF per unit
  valueColor: Colors.orange,
),
_buildCpfDetailRow(
  "${context.tr("CPF for")} ${units.toStringAsFixed(1)} $unitText",
                 //   "₹$cpfAmount",
                  "${FormatUtils.formatAmountWithCurrency(quantity * cpfPerBuffalo)}",
),
                const SizedBox(height: 4),
                const Divider(thickness: 1.5),
                const SizedBox(height: 4),
_buildCpfDetailRow(
  context.tr("Total CPF Cost"),
                  //  "₹$cpfAmount",
                  "${FormatUtils.formatAmountWithCurrency(quantity * cpfPerBuffalo)}", // only paid CPF
  valueColor: kPrimaryDarkColor,
  isBold: true,
),
              ],
            ],
          ),
        ),

        // if (isCpfSelected) ...[
        //   const SizedBox(height: 16),
        //   PaymentSummary(
        //     buffalo: buffalo,
        //     quantity: quantity,
        //     units: units,
        //     unitText: unitText,
        //     buffaloPrice: buffaloPrice,
        //     cpfAmount: cpfAmount,
        //     totalAmount: totalAmount,
        //     cpfUnitsToPay: cpfUnitsToPay,
        //     freeCpfUnits: freeCpfUnits,
        //   ),
        // ],
      ],
    );
  }

  Widget _buildCpfDetailRow(
    String label,
    String value, {
    Color? valueColor,
    bool isBold = false,
    double fontSize = 14,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: fontSize,
                fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.w700,
              color: valueColor ?? kPrimaryGreen,
              
            ),
          ),
        ],
      ),
    );
  }
}
