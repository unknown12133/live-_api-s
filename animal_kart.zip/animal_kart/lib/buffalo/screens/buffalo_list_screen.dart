import 'package:animal_kart_demo2/buffalo/providers/buffalo_provider.dart';

import 'package:animal_kart_demo2/widgets/Shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';

import '../widgets/buffalo_card.dart';

class BuffaloListScreen extends ConsumerWidget {
  const BuffaloListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final buffaloAsync = ref.watch(buffaloListProvider);

    return Container(
      color: Theme.of(context).mainThemeBgColor,
      child: buffaloAsync.when(
        loading: () => Center(
          child: ordersShimmerList()
         // CircularProgressIndicator(color: kPrimaryGreen),
        ),

        error: (err, _) => Center(
          child: Text(
            "Failed to load buffalos\n$err",
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
        ),

        data: (buffalos) => ListView.builder(
          padding: const EdgeInsets.only(bottom: 90, top: 12),
          itemCount: buffalos.length,
          itemBuilder: (context, i) => BuffaloCard(buffalo: buffalos[i]),
        ),
      ),
    );
  }
}
