class Buffalo {
  final String id;
  final String breed;
  final int? age;
  final int milkYield;
  final int price;
  final bool inStock;
  final int insurance;
  final String? oneUnit; // FIXED
  final String? location; // OPTIONAL
  final DateTime? timestamp; // OPTIONAL
  final List<String> buffaloImages;
  final String description;

  Buffalo({
    required this.id,
    required this.breed,
    this.age,
    required this.milkYield,
    required this.price,
    required this.inStock,
    required this.insurance,
    this.oneUnit,
    this.location,
    this.timestamp,
    required this.buffaloImages,
    required this.description,
  });

  factory Buffalo.fromJson(Map<String, dynamic> json) {
    return Buffalo(
      id: json['id'],
      breed: json['breed'],
      age: json['age'],
      milkYield: json['milkYield'],
      price: json['price'],
      inStock: json['inStock'],
      insurance: json['insurance'],
      oneUnit: json['ONE_UNIT'],
      location: json['location'],
      timestamp: json['timestamp'] != null
          ? DateTime.parse(json['timestamp'])
          : null,
      buffaloImages: List<String>.from(json['buffalo_images']),
      description: json['description'],
    );
  }
}
