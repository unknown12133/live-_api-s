import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:animal_kart_demo2/routes/routes.dart';
import 'package:animal_kart_demo2/utils/app_colors.dart';
import 'package:animal_kart_demo2/utils/app_constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with TickerProviderStateMixin {
  // Animation controllers for different stages
  late AnimationController _dropController;
  late AnimationController _zoomController;
  late AnimationController _expandController;
  late AnimationController _finalController;

  // Animations
  late Animation<double> _dropAnimation;
  late Animation<double> _iconScaleAnimation;
  late Animation<double> _circleScaleAnimation;
  late Animation<double> _finalIconScaleAnimation;

  // Stage tracking
  int _currentStage = 0; // 0: white, 1: drop, 2: zoom, 3: expand, 4: final

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startAnimationSequence();
  }

  void _initializeAnimations() {
    // Stage 1: Drop animation (icon drops from top)
    _dropController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _dropAnimation = Tween<double>(begin: -300.0, end: 0.0).animate(
      CurvedAnimation(parent: _dropController, curve: Curves.bounceOut),
    );

    // Stage 2: Zoom animation (icon grows)
    _zoomController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _iconScaleAnimation = Tween<double>(begin: 1.0, end: 1.6).animate(
      CurvedAnimation(parent: _zoomController, curve: Curves.easeInOut),
    );

    // Stage 3: Circle expansion
    _expandController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _circleScaleAnimation = Tween<double>(begin: 1.0, end: 15.0).animate(
      CurvedAnimation(parent: _expandController, curve: Curves.easeInOutQuad),
    );

    // Stage 4: Final icon scale
    _finalController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _finalIconScaleAnimation = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _finalController, curve: Curves.elasticOut),
    );
  }

  void _startAnimationSequence() async {
    // Stage 0: White screen
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;

    // Stage 1: Icon drops from top
    setState(() => _currentStage = 1);
    await _dropController.forward();
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;

    // Stage 2: Icon zooms in
    setState(() => _currentStage = 2);
    await _zoomController.forward();
    await Future.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;

    // Stage 3: Circle expands to fill screen
    setState(() => _currentStage = 3);
    await _expandController.forward();
    if (!mounted) return;

    // Stage 4: Final identity screen
    setState(() => _currentStage = 4);
    await _finalController.forward();

    // Check login status and navigate
    await _checkAuthAndNavigate();
  }

  Future<void> _checkAuthAndNavigate() async {
    // Short extra delay for visual impact
    await Future.delayed(const Duration(milliseconds: 1500));
    if (!mounted) return;

    final prefs = await SharedPreferences.getInstance();
    final bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
    final bool isFormFilled = prefs.getBool('isFormFilled') ?? false;
    final String? userMobile = prefs.getString('userMobile');

    await _requestNotificationPermission();

    if (isLoggedIn) {
      if (isFormFilled) {
        Navigator.pushReplacementNamed(context, AppRouter.home);
      } else if (userMobile != null && userMobile.isNotEmpty) {
        Navigator.pushReplacementNamed(
          context,
          AppRouter.login,
          arguments: {'phoneNumberFromLogin': userMobile},
        );
      } else {
        // If logged in but no mobile or form not filled, safer to go to login
        Navigator.pushReplacementNamed(context, AppRouter.onBoardingScreen);
      }
    } else {
      Navigator.pushReplacementNamed(context, AppRouter.onBoardingScreen);
    }
  }

  Future<void> _requestNotificationPermission() async {
    if (kIsWeb) return; // Permission handler not used on web this way
    try {
      final status = await Permission.notification.status;
      if (status.isDenied) {
        await Permission.notification.request();
      }
    } catch (e) {
      debugPrint("Notification permission check failed: $e");
      // Silently fail to allow app to continue
    }
  }

  @override
  void dispose() {
    _dropController.dispose();
    _zoomController.dispose();
    _expandController.dispose();
    _finalController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _currentStage >= 3 ? kPrimaryGreen : kWhite,
      body: Stack(
        children: [
          // Background Glow for Stages 1 & 2
          if (_currentStage > 0 && _currentStage < 3)
            Positioned.fill(
              child: Image.asset(
                'assets/images/Invoice_background.jpeg',
                fit: BoxFit.cover,
                opacity: const AlwaysStoppedAnimation(0.05),
              ),
            ),

          // Stage 1-2: White background with animated floating icon
          if (_currentStage > 0 && _currentStage < 3)
            Center(
              child: AnimatedBuilder(
                animation: Listenable.merge([_dropController, _zoomController]),
                builder: (context, child) {
                  return Transform.translate(
                    offset: Offset(0, _dropAnimation.value),
                    child: Transform.scale(
                      scale: _currentStage >= 2
                          ? _iconScaleAnimation.value
                          : 1.0,
                      child: Container(
                        width: 100,
                        height: 100,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: kPrimaryGreen,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: kPrimaryGreen.withOpacity(0.3),
                              blurRadius: 25,
                              spreadRadius: 8,
                            ),
                          ],
                        ),
                        child: Image.asset(
                          AppConstants.onBoardAppLogo,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

          // Stage 3: The Big Expansion
          if (_currentStage == 3)
            Center(
              child: AnimatedBuilder(
                animation: _expandController,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _circleScaleAnimation.value,
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: const BoxDecoration(
                        color: kPrimaryGreen,
                        shape: BoxShape.circle,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Image.asset(
                          AppConstants.onBoardAppLogo,
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

          // Stage 4: Premium Identity Reveal
          if (_currentStage == 4)
            Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [kPrimaryGreen, kPrimaryDarkGreen],
                ),
              ),
              child: Center(
                child: AnimatedBuilder(
                  animation: _finalController,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _finalIconScaleAnimation.value,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Main Mascot Logo
                          Container(
                            width: 180,
                            height: 180,
                            padding: const EdgeInsets.all(28),
                            decoration: BoxDecoration(
                              color: kWhite.withOpacity(0.12),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: kWhite.withOpacity(0.2),
                                width: 2,
                              ),
                            ),
                            child: Image.asset(
                              AppConstants.onBoardAppLogo,
                              fit: BoxFit.contain,
                            ),
                          ),

                          const SizedBox(height: 50),

                          // Text Branding
                          Image.asset(
                            'assets/images/app_name_logo.png',
                            height: 120,
                            fit: BoxFit.contain,
                          ),

                          const SizedBox(height: 12),

                          // Decorative bar
                          Container(
                            height: 3,
                            width: 50,
                            decoration: BoxDecoration(
                              color: kAccentLime,
                              borderRadius: BorderRadius.circular(2),
                              boxShadow: [
                                BoxShadow(
                                  color: kAccentLime.withOpacity(0.4),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 20),

                          // Premium Tagline
                          Text(
                            "PREMIUM CATTLE MARKETPLACE",
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 4.5,
                              color: kWhite.withOpacity(0.85),
                              shadows: [
                                Shadow(
                                  color: Colors.black.withOpacity(0.25),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
        ],
      ),
    );
  }
}
