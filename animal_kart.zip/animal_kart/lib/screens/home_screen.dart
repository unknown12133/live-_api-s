import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';
import 'package:animal_kart_demo2/auth/models/user_model.dart';
import 'package:animal_kart_demo2/buffalo/screens/buffalo_list_screen.dart';
import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/orders/providers/orders_providers.dart';
import 'package:animal_kart_demo2/orders/screens/orders_screen.dart';
import 'package:animal_kart_demo2/profile/screens/user_profile_screen.dart';
import 'package:animal_kart_demo2/profile/providers/profile_provider.dart';
import 'package:animal_kart_demo2/routes/routes.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/services/update_service.dart';
import 'package:animal_kart_demo2/utils/save_user.dart';
import 'package:animal_kart_demo2/widgets/internet_check_wrapper.dart';
import 'package:animal_kart_demo2/helpdesk/screens/helpdesk_screen.dart';
import 'package:animal_kart_demo2/refer_earn/screens/refer_earn_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animal_kart_demo2/auth/providers/auth_provider.dart';
import 'package:animal_kart_demo2/services/secure_storage_service.dart';

class HomeScreen extends ConsumerStatefulWidget {
  final int selectedIndex;

  const HomeScreen({super.key, this.selectedIndex = 0});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  DateTime? currentBackPressTime;

  late final List<Widget> _pages;
  UserModel? localUser;

  late AnimationController _coinController;

  @override
  void initState() {
    super.initState();

    _selectedIndex = widget.selectedIndex;

    _pages = const [
      InternetCheckWrapper(showFullPage: true, child: BuffaloListScreen()),
      InternetCheckWrapper(showFullPage: true, child: OrdersScreen()),
      InternetCheckWrapper(showFullPage: true, child: ReferEarnScreen()),
      InternetCheckWrapper(showFullPage: true, child: HelpDeskScreen()),
      InternetCheckWrapper(showFullPage: true, child: UserProfileScreen()),
    ];

    _coinController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    // Call profile API on home load to check isActive status globally
    Future.microtask(() {
      ref.read(profileProvider.notifier).fetchCurrentUser();
    });

    _loadLocalUser();

    // Run update check once after first frame (post successful login navigates here)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      UpdateService.checkAndPrompt(context);
    });
  }

  @override
  void dispose() {
    _coinController.dispose();
    super.dispose();
  }

  Future<void> _loadLocalUser() async {
    localUser = await loadUserFromPrefs();
    if (localUser != null && !localUser!.isActive) {
      _handleAccountDeactivation();
      return;
    }
    setState(() {});
  }

  bool _isDeactivationDialogShowing = false;

  Future<void> _handleAccountDeactivation() async {
    if (!mounted || _isDeactivationDialogShowing) return;
    _isDeactivationDialogShowing = true;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        icon: const Icon(
          Icons.lock_person_rounded,
          color: kPrimaryRed,
          size: 48,
        ),
        title: Text(
          context.tr('Account Deactivated'),
          textAlign: TextAlign.center,
          style: tsFont20700_Gotham.copyWith(color: kPrimaryRed),
        ),
        content: Text(
          context.tr(
            'Your account has been deactivated. Please contact support for more information.',
          ),
          textAlign: TextAlign.center,
          style: tsFont16400.copyWith(color: kTextSecondary),
        ),
        actions: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: kPrimaryRed,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
              child: Text(
                context.tr('OK'),
                style: tsFont16700.copyWith(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );

    _isDeactivationDialogShowing = false;
    await _performLogout();
  }

  Future<void> _performLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    await SecureStorageService.enableBiometric(false);
    ref.read(authProvider.notifier).clearSession();
    if (context.mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRouter.login,
        (route) => false,
      );
    }
  }

  Future<void> _onItemTapped(int index) async {
    // 1. Always refresh profile on every tab tap to check isActive status globally
    ref.read(profileProvider.notifier).fetchCurrentUser();

    if (index == 1) {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString('userMobile');
      if (userId != null) {
        ref.read(ordersProvider.notifier).loadOrders(userId: userId);
      }
    }

    setState(() => _selectedIndex = index);
  }

  void _goToHomeTab() => setState(() => _selectedIndex = 0);

  @override
  Widget build(BuildContext context) {
    ref.listen(profileProvider, (previous, next) {
      if (next.currentUser != null && next.currentUser!.isActive == false) {
        _handleAccountDeactivation();
      }
    });

    return InternetCheckWrapper(
      showSnackbar: true,
      child: WillPopScope(
        onWillPop: () async {
          if (_selectedIndex != 0) {
            _goToHomeTab();
            return false;
          } else {
            DateTime now = DateTime.now();
            if (currentBackPressTime == null ||
                now.difference(currentBackPressTime!) >
                    const Duration(seconds: 2)) {
              currentBackPressTime = now;
              CustomSnackBar.show(
                context,
                title: 'Warning',
                message: 'Tap again to exit',
                contentType: ContentType.warning,
                duration: const Duration(seconds: 2),
              );
              return false;
            }
            SystemNavigator.pop();
            return false;
          }
        }, 
       child: SafeArea(
  top: false, // AppBar already handles top
  bottom: true,
  
        child: Scaffold(
          backgroundColor: Theme.of(context).mainThemeBgColor,
          appBar: _selectedIndex == 2 ? null : _buildAppBar(context),
          body: IndexedStack(index: _selectedIndex, children: _pages),
          bottomNavigationBar: _buildBottomNav(),
        ),
      ),
      )
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Theme.of(context).isLightTheme
          ? kPrimaryDarkColor
          : Colors.grey[850],
      elevation: 0,
      toolbarHeight: 90,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
      ),
      centerTitle: _selectedIndex != 0,
      title: _buildTitle(context),
      actions: _buildActions(context),
    );
  }

  Widget _buildTitle(BuildContext context) {
    final user = ref.watch(profileProvider).currentUser;
    if (_selectedIndex == 4) {
      return Column(
        children: [
          Text(
            user?.name ?? 'User Profile',
            style: tsFont24Bold.copyWith(color: Colors.white),
          ),
          Text(
            '+91 ${localUser?.mobile ?? ''}',
            style: tsFont18700.copyWith(
              color: Colors.white.withValues(alpha: 0.5),
            ),
          ),
        ],
      );
    } else if (_selectedIndex == 1) {
      return Text(
        context.tr("orderHistory"),
        style: tsFont24Bold.copyWith(color: kWhite),
      );
    } else if (_selectedIndex == 3) {
      return Text(
        context.tr("HelpDesk"),
        style: tsFont24Bold.copyWith(color: kWhite),
      );
    } else {
      return Image.asset('assets/images/onboard_logo.png', height: 50);
    }
  }

  List<Widget> _buildActions(BuildContext context) {
    if (_selectedIndex == 0) {
      return [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white24,
            ),
            child: IconButton(
              icon: const Icon(Icons.notifications_none, color: Colors.white),
              onPressed: () {
                // Navigator.pushNamed(context, AppRouter.notification);
              },
            ),
          ),
        ),
      ];
    }
    return [];
  }

  // ---------------- BOTTOM NAV ----------------

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).isLightTheme ? Colors.white : Colors.grey[850],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _navItem(0, Icons.home_rounded, Icons.home_outlined, "Home"),
              _navItem(
                1,
                Icons.shopping_cart,
                Icons.shopping_cart_outlined,
                "Orders",
              ),
              _coinNavItem(),
              _navItem(
                3,
                FontAwesomeIcons.phoneVolume,
                FontAwesomeIcons.phoneVolume,
                "HelpDesk",
                size: 16,
              ),
              _navItem(4, Icons.person, Icons.person_outline, "Profile"),
            ],
          ),
        ),
      ),
    );
  }


///////
/// If IOS
/// Widget _buildBottomNav() {
//   return SafeArea(
//     top: false,
//     child: BottomNavigationBar(
//       currentIndex: _selectedIndex,
//       onTap: _onItemTapped,
//       type: BottomNavigationBarType.fixed,
//       backgroundColor:
//           Theme.of(context).isLightTheme ? Colors.white : Colors.grey[850],
//       selectedItemColor: kPrimaryGreen,
//       unselectedItemColor: Colors.grey,
//       selectedFontSize: 10,
//       unselectedFontSize: 10,
//       items: const [
//         BottomNavigationBarItem(
//           icon: Icon(Icons.home_outlined),
//           activeIcon: Icon(Icons.home_rounded),
//           label: 'Home',
//         ),
//         BottomNavigationBarItem(
//           icon: Icon(Icons.shopping_cart_outlined),
//           activeIcon: Icon(Icons.shopping_cart),
//           label: 'Orders',
//         ),
//         BottomNavigationBarItem(
//           icon: Icon(Icons.card_giftcard_outlined),
//           activeIcon: Icon(Icons.card_giftcard),
//           label: 'Rewards',
//         ),
//         BottomNavigationBarItem(
//           icon: Icon(Icons.phone),
//           label: 'HelpDesk',
//         ),
//         BottomNavigationBarItem(
//           icon: Icon(Icons.person_outline),
//           activeIcon: Icon(Icons.person),
//           label: 'Profile',
//         ),
//       ],
//     ),
//   );
// }


  Widget _navItem(
    int index,
    IconData active,
    IconData inactive,
    String label, {
    double size = 26,
  }) {
    final isSelected = _selectedIndex == index;

    return InkWell(
      borderRadius: BorderRadius.circular(30),
      onTap: () => _onItemTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 30, // 👈 NORMALIZES icon spacing for all icons
            child: Center(
              child: Icon(
                isSelected ? active : inactive,
                size: size,
                color: isSelected ? kPrimaryGreen : Colors.grey,
              ),
            ),
          ),

          const SizedBox(height: 4), // 👈 consistent gap

          Text(
            context.tr(label),
            style: tsFont11700.copyWith(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              height: 1.0,
              color: isSelected ? kPrimaryGreen : Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _coinNavItem() {
    final bool isSelected = _selectedIndex == 2;

    return InkWell(
      customBorder: const CircleBorder(),
      onTap: () {
        _coinController.forward(from: 0);
        _onItemTapped(2);
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _coinController,
            builder: (_, __) {
              final scale = 1 + (_coinController.value * 0.12);

              return Transform.scale(
                scale: scale,
                child: Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: isSelected
                          ? [kPrimaryGreen, Colors.greenAccent]
                          : [kPrimaryGreen, Colors.greenAccent],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: (isSelected ? kPrimaryGreen : kPrimaryGreen)
                            .withOpacity(0.4),
                        blurRadius: 12,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      context.tr("Refer & Earn"),
                      textAlign: TextAlign.center,
                      style: tsFont11700.copyWith(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
