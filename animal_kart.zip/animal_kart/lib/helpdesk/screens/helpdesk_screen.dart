import 'package:animal_kart_demo2/helpdesk/screens/faq_screen.dart';
import 'package:animal_kart_demo2/profile/providers/profile_provider.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/custom_page_route.dart';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class HelpDeskScreen extends StatelessWidget {
  const HelpDeskScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer(
      builder: (context, ref, child) {
        final profileState = ref.watch(profileProvider);
        final userRole = profileState.currentUser?.role ?? '';

        return Scaffold(
          backgroundColor: Theme.of(context).mainThemeBgColor,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 1.1,
                    children: [
                      _buildHelpCard(
                        icon: Icons.error_outline_rounded,
                        title: 'Raise a Request',
                        onTap: () {},
                      ),
                      _buildHelpCard(
                        icon: Icons.confirmation_number_outlined,
                        title: 'Track my tickets',
                        onTap: () {},
                      ),
                      _buildHelpCard(
                        icon: Icons.quiz_outlined,
                        title: 'Frequently asked questions',
                        onTap: () {
                          Navigator.push(
                            context,
                            RightToLeftPageRoute(child: FAQScreen(userRole: userRole)),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHelpCard({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kWhite,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kTextSecondary.withOpacity(0.05)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0F1FF),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: const Color(0xFF3F418E), size: 26),
                ),
                const Icon(
                  Icons.chevron_right_rounded,
                  color: Color(0xFF3F418E),
                  size: 20,
                ),
              ],
            ),
            Text(
              title,
              style: tsFont16700.copyWith(color: const Color(0xFF1A1C3D)),
            ),
          ],
        ),
      ),
    );
  }
}
