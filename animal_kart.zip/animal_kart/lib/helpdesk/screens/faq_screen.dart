import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:flutter/material.dart';

class FAQScreen extends StatefulWidget {
  final String? userRole;
  
  const FAQScreen({super.key, this.userRole});

  @override
  State<FAQScreen> createState() => _FAQScreenState();
}

class _FAQScreenState extends State<FAQScreen> {
  int? expandedIndex;

  List<Map<String, String>> get faqs {
    final isEmployee = widget.userRole?.toLowerCase() == 'employee';
    
    if (isEmployee) {
      return [
        {
          'question': 'What is Animal Kart?',
          'answer':
              'Animal Kart is a digital platform that allows you to purchase units of high-quality livestock and earn returns through professional management.',
        },
        {
          'question': 'What is a Murrah buffalo and how can I identify it?',
          'answer':
              'The Murrah buffalo is one of the best dairy buffalo breeds in India, well known for its high milk yield, strong genetics, and adaptability to different climatic conditions.\n\n'
              'Identification features of Murrah Buffalo:\n'
              '• Jet-black skin colour\n'
              '• Short, tightly curved horns (spiral shape)\n'
              '• Broad head with a prominent forehead\n'
              '• Well-developed udder\n'
              '• Strong and compact body structure\n'
              '• High milk-producing capacity',
        },
         {
          'question': 'How can I identify a female Murrah buffalo in India?',
          'answer':
              'A female Murrah buffalo can be identified using the following characteristics:\n\n'
              '• Deep black skin without patches\n'
              '• Medium to large body size\n'
              '• Small, thick, and tightly curved horns\n'
              '• Well-shaped udder with evenly placed teats\n'
              '• Calm temperament and good feeding response\n'
              '• High milk yield potential\n\n'
              'All female Murrah buffaloes provided through Animal Kart are carefully selected and verified by experts.',
        },
        {
          'question': 'What is CPF?',
          'answer':
              'CPF (Cattle Protection Fund) is an protection for your investment, covering risks associated with livestock health.',
        },
         {
          'question':
              'After purchasing, how does delivery work and why is there a 6-month gap for the next buffalo unit?',
          'answer':
              'When you purchase 1 unit, you receive:\n\n'
              '• 2 Murrah buffaloes\n'
              '• 2 calves\n\n'
              'Delivery cycle explanation:\n'
              '• 1 Murrah buffalo + 1 calf will be transported to the farm within 1 month\n'
              '• The remaining 1 Murrah buffalo + 1 calf will be imported and delivered within 6 months\n\n'
              'This structured cycle ensures:\n'
              '• Continuous monthly revenue\n'
              '• Proper quarantine and health monitoring\n'
              '• Reduced operational risk\n'
              '• Better long-term profitability\n\n'
              'This delivery cycle is designed to maximize income stability and overall profit.',
        },
        {
          'question': 'Why is CPF (Cattle Protection Fund) mandatory?',
          'answer':
              'CPF is mandatory to ensure complete protection and long-term security of your livestock investment.\n\n'
              'CPF benefits include:\n'
              '• Full medical care in case of health issues\n'
              '• Replacement of buffalo in case of critical loss\n'
              '• Artificial insemination support to ensure the birth of female Murrah calves only\n'
              '• Continuous health monitoring\n'
              '• Live CCTV access to monitor your buffaloes in real time\n\n'
              'CPF safeguards your asset and ensures uninterrupted income generation.',
        },
        {
          'question': 'Why do I need to purchase at least 1 unit?',
          'answer':
              '1 unit includes:\n'
              '• 2 Murrah buffaloes\n'
              '• 2 calves\n\n'
              'Purchasing 1 full unit is mandatory because:\n'
              '• It ensures higher and more stable income\n'
              '• It supports proper milk production cycles\n'
              '• It enables eligibility for CPF benefits\n'
              '• It provides long-term profit scalability\n\n'
              'Purchasing only 1 buffalo + 1 calf does not generate sufficient income or profit and is therefore not supported.',
        },
        {
          'question': 'How do I purchase a unit?',
          'answer':
              'Browse the buffalo list, select a breed, choose the number of units, and complete the payment using Online or Manual payment options.',
        },
        {
  'question': 'How does the referral program work for employees?',
  'answer':
      'As an employee, you can start referring friends immediately. No purchase is required. Simply enter your friends’ contact details in the "Refer & Earn" section and earn rewards when they make a purchase.',
},

        {
          'question': 'What rewards do I get for referrals?',
          'answer':
             'You earn coins based on the unit cost for every unit your friend purchases. These coins can be accumulated to unlock more units'
        },
        {
          'question': 'Are the referral rewards cumulative?',
          'answer':
              'Yes! If your friend purchases multiple units at once or over time, you receive rewards for each unit they buy',
        },
        {
          'question': 'How can I track my referrals?',
          'answer':
              'You can track all your successful referrals and earned coins in the "Refer & Earn" section under "Track my referrals". Monitor your bonus earnings and total rewards.',
        },
        {
          'question': 'What are the payment options?',
          'answer':
              'We support Online payment via Razorpay for instant confirmation and Manual payment (Direct Bank Transfer) for larger amounts.',
        },
        {
          'question': 'Can I sell or transfer my units?',
          'answer':
              'Yes, units can be transferred or sold within the platform according to the terms of service after a minimum holding period.',
        },
        {
          'question': 'How do I contact support?',
          'answer':
              'If you have any issues, you can "Raise a Request" in the Help Desk, or use our WhatsApp support for quick assistance.',
        },
      ];
    } else {
      // Default content for investors
      return [
        {
          'question': 'What is Animal Kart?',
          'answer':
              'Animal Kart is a digital platform that allows you to purchase units of high-quality livestock and earn returns through professional management.',
        },
        {
          'question': 'What is a Murrah buffalo and how can I identify it?',
          'answer':
              'The Murrah buffalo is one of the best dairy buffalo breeds in India, well known for its high milk yield, strong genetics, and adaptability to different climatic conditions.\n\n'
              'Identification features of Murrah Buffalo:\n'
              '• Jet-black skin colour\n'
              '• Short, tightly curved horns (spiral shape)\n'
              '• Broad head with a prominent forehead\n'
              '• Well-developed udder\n'
              '• Strong and compact body structure\n'
              '• High milk-producing capacity',
        },
        {
          'question': 'How can I identify a female Murrah buffalo in India?',
          'answer':
              'A female Murrah buffalo can be identified using the following characteristics:\n\n'
              '• Deep black skin without patches\n'
              '• Medium to large body size\n'
              '• Small, thick, and tightly curved horns\n'
              '• Well-shaped udder with evenly placed teats\n'
              '• Calm temperament and good feeding response\n'
              '• High milk yield potential\n\n'
              'All female Murrah buffaloes provided through Animal Kart are carefully selected and verified by experts.',
        },
        {
          'question': 'What is CPF?',
          'answer':
              'CPF (Cattle Protection Fund) is an protection for your investment, covering risks associated with livestock health.',
        },
        {
          'question':
              'After purchasing, how does delivery work and why is there a 6-month gap for the next buffalo unit?',
          'answer':
              'When you purchase 1 unit, you receive:\n\n'
              '• 2 Murrah buffaloes\n'
              '• 2 calves\n\n'
              'Delivery cycle explanation:\n'
              '• 1 Murrah buffalo + 1 calf will be transported to the farm within 1 month\n'
              '• The remaining 1 Murrah buffalo + 1 calf will be imported and delivered within 6 months\n\n'
              'This structured cycle ensures:\n'
              '• Continuous monthly revenue\n'
              '• Proper quarantine and health monitoring\n'
              '• Reduced operational risk\n'
              '• Better long-term profitability\n\n'
              'This delivery cycle is designed to maximize income stability and overall profit.',
        },
        {
          'question': 'Why is CPF (Cattle Protection Fund) mandatory?',
          'answer':
              'CPF is mandatory to ensure complete protection and long-term security of your livestock investment.\n\n'
              'CPF benefits include:\n'
              '• Full medical care in case of health issues\n'
              '• Replacement of buffalo in case of critical loss\n'
              '• Artificial insemination support to ensure the birth of female Murrah calves only\n'
              '• Continuous health monitoring\n'
              '• Live CCTV access to monitor your buffaloes in real time\n\n'
              'CPF safeguards your asset and ensures uninterrupted income generation.',
        },
        {
          'question': 'Why do I need to purchase at least 1 unit?',
          'answer':
              '1 unit includes:\n'
              '• 2 Murrah buffaloes\n'
              '• 2 calves\n\n'
              'Purchasing 1 full unit is mandatory because:\n'
              '• It ensures higher and more stable income\n'
              '• It supports proper milk production cycles\n'
              '• It enables eligibility for CPF benefits\n'
              '• It provides long-term profit scalability\n\n'
              'Purchasing only 1 buffalo + 1 calf does not generate sufficient income or profit and is therefore not supported.',
        },
        {
          'question': 'How do I purchase a unit?',
          'answer':
              'Browse the buffalo list, select a breed, choose the number of units, and complete the payment using Online or Manual payment options.',
        },
        {
          'question': 'How does the referral program work?',
          'answer':
              'Once you purchase your first unit, your referral feature is unlocked. You can then refer friends by entering their contact details in the "Refer & Earn" section.',
        },
        {
          'question': 'What rewards do I get for referrals?',
          'answer':
             'You earn coins based on the unit cost for every unit your friend purchases. These coins can be accumulated to unlock more units'
        },
        {
          'question': 'Are the referral rewards cumulative?',
          'answer':
              'Yes! If your friend purchases multiple units at once or over time, you receive rewards for each unit they buy',
        },
        {
          'question': 'How can I track my referrals?',
          'answer':
              'You can track all your successful referrals and earned coins in the "Refer & Earn" section under "Track my referrals".',
        },
        {
          'question': 'What are the payment options?',
          'answer':
              'We support Online payment via Razorpay for instant confirmation and Manual payment (Direct Bank Transfer) for larger amounts.',
        },
        {
          'question': 'Can I sell or transfer my units?',
          'answer':
              'Yes, units can be transferred or sold within the platform according to the terms of service after a minimum holding period.',
        },
        {
          'question': 'How do I contact support?',
          'answer':
              'If you have any issues, you can "Raise a Request" in the Help Desk, or use our WhatsApp support for quick assistance.',
        },
      ];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
     appBar: AppBar(
        backgroundColor: kPrimaryGreen,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'FAQ',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
       // centerTitle: true,
      ),
      body: PageStorage(
        bucket: PageStorageBucket(),
        child: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: faqs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            return Container(
              decoration: BoxDecoration(
                color: kWhite,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black.withOpacity(0.05)),
              ),
              child: Theme(
                data: Theme.of(
                  context,
                ).copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                  key: ValueKey('${index}_$expandedIndex'),
                  initiallyExpanded: expandedIndex == index,
                  onExpansionChanged: (isExpanded) {
                    setState(() {
                      expandedIndex = isExpanded ? index : null;
                    });
                  },
                  title: Text(
                    faqs[index]['question']!,
                    style: tsFont16700.copyWith(color: const Color(0xFF1A1C3D)),
                  ),
                  iconColor: const Color(0xFF3F418E),
                  collapsedIconColor: const Color(0xFF3F418E),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  children: [
                    Text(
                      faqs[index]['answer']!,
                      style: tsFont14400.copyWith(
                        color: kTextSecondary,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
