import 'dart:io' show Platform;

import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/styles.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:in_app_update/in_app_update.dart';
import 'package:animal_kart_demo2/utils/app_colors.dart';

class UpdateService {
  UpdateService._();
  static bool _promptedThisSession = false;

  static Future<void> checkAndPrompt(BuildContext context) async {
    if (_promptedThisSession) return;
    _promptedThisSession = true;
    try {
      final data = await _fetchConfig();
      if (data == null) return;

      final info = await PackageInfo.fromPlatform();
      final currentVersion = info.version;

      final bool forceUpdate = Platform.isAndroid
          ? (data['android_force_update'] as bool? ?? false)
          : (data['ios_force_update'] as bool? ?? false);

      final String minSupported = Platform.isAndroid
          ? (data['android_min_supported'] as String? ?? '0.0.0')
          : (data['ios_min_supported'] as String? ?? '0.0.0');

      final String latest = Platform.isAndroid
          ? (data['android_latest'] as String? ?? currentVersion)
          : (data['ios_latest'] as String? ?? currentVersion);

      final String storeUrl = Platform.isAndroid
          ? (data['android_store_url'] as String? ?? '')
          : (data['ios_store_url'] as String? ?? '');

      final String message =
          (data['update_message'] as String?) ?? 'A new update is available.';

      final needsForce = _compareVersions(currentVersion, minSupported) < 0;
      final hasOptional = _compareVersions(currentVersion, latest) < 0;

      if (!needsForce && !hasOptional) return;

      // Attempt Android native in-app update sheet first
      if (Platform.isAndroid) {
        final usedNative = await _tryAndroidInAppUpdate(
          forceUpdate || needsForce,
        );
        if (usedNative) return; // Native sheet handled it
      }

      // Fallback dialog (iOS and Android failures)
      await _showPrompt(
        context: context,
        storeUrl: storeUrl,
        force: forceUpdate || needsForce,
        message: message,
      );
    } catch (_) {
      // Silently ignore update check failures
    }
  }

  static Future<bool> _tryAndroidInAppUpdate(bool force) async {
    try {
      final info = await InAppUpdate.checkForUpdate();
      if (info.updateAvailability == UpdateAvailability.updateAvailable) {
        if (force) {
          await InAppUpdate.performImmediateUpdate();
        } else {
          await InAppUpdate.startFlexibleUpdate();
          await InAppUpdate.completeFlexibleUpdate();
        }
        return true;
      }
    } catch (_) {
      // ignore and fallback
    }
    return false;
  }

  static Future<Map<String, dynamic>?> _fetchConfig() async {
    final snap = await FirebaseFirestore.instance
        .doc('animal_kart_app_config/app_version')
        .get(const GetOptions(source: Source.serverAndCache));
    if (!snap.exists) return null;
    return snap.data();
  }

  // Returns -1 if a < b, 0 if equal, 1 if a > b
  static int _compareVersions(String a, String b) {
    List<int> pa = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    List<int> pb = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    while (pa.length < 3) pa.add(0);
    while (pb.length < 3) pb.add(0);
    for (int i = 0; i < 3; i++) {
      if (pa[i] != pb[i]) return pa[i] < pb[i] ? -1 : 1;
    }
    return 0;
  }

  static Future<void> _showPrompt({
  required BuildContext context,
  required String storeUrl,
  required bool force,
  required String message,
}) async {
  Future<void> openStore() async {
    final uri = Uri.parse(storeUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  
         await showModalBottomSheet(
  context: context,
  isDismissible: true,
  isScrollControlled: true,
  backgroundColor: Colors.transparent,
  builder: (_) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
        decoration: const BoxDecoration(
          color: kWhite,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            /// App icon / Update icon
            Container(
              height: 72,
              width: 72,
              decoration: BoxDecoration(
                color: kPrimaryGreen.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Image.asset(
                  'assets/images/AppLogo.png', // 🔁 your app icon
                  height: 42,
                ),
              ),
            ),

            const SizedBox(height: 16),

            /// Title
            Text(
              'Update Available',
              style: tsFont24Bold,
              textAlign: TextAlign.center,
            ),

            const SizedBox(height: 8),

            /// Message
            Text(
              message,
              textAlign: TextAlign.center,
              style: tsFont12400.copyWith(
                fontSize: 14,
                color: Colors.grey.shade700,
                height: 1.4,
              ),
            ),

            const SizedBox(height: 24),

            /// Buttons
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 46,
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: buttonColor1),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'Later',
                        style: TextStyle(
                          color: buttonColor1,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 12),

                Expanded(
                  child: SizedBox(
                    height: 46,
                    child: ElevatedButton(
                      onPressed: () async {
                        await openStore();
                        if (context.mounted) Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryGreen,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Update',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  },
);

}

   
  
}