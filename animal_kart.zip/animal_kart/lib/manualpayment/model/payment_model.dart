class PaymentResponse {
  final int statusCode;
  final String status;
  final String message;
  final Order? order;

  PaymentResponse({
    required this.statusCode,
    required this.status,
    required this.message,
    this.order,
  });

  factory PaymentResponse.fromJson(Map<String, dynamic> json) {
    return PaymentResponse(
      statusCode: json['statuscode'] ?? 0,
      status: json['status'] ?? '',
      message: json['message'] ?? '',
      order: json['order'] != null ? Order.fromJson(json['order']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'statuscode': statusCode,
      'status': status,
      'message': message,
      'order': order?.toJson(),
    };
  }
}

class Order {
  final double baseUnitCost;
  final String paymentMode;
  final String breedId;
  final double calfCount;
  final String userId;
  final String paymentType;
  final double buffaloCount;
  final double numUnits;
  final bool withCpf;
  final double unitCost;
  final String id;
  final DateTime placedAt;
  final double cpfUnitCost;
  final String paymentStatus;
  final double totalCost;

  Order({
    required this.baseUnitCost,
    required this.paymentMode,
    required this.breedId,
    required this.calfCount,
    required this.userId,
    required this.paymentType,
    required this.buffaloCount,
    required this.numUnits,
    required this.withCpf,
    required this.unitCost,
    required this.id,
    required this.placedAt,
    required this.cpfUnitCost,
    required this.paymentStatus,
    required this.totalCost,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      baseUnitCost: (json['baseUnitCost'] ?? 0).toDouble(),
      paymentMode: json['paymentMode'] ?? '',
      breedId: json['breedId'] ?? '',
      calfCount: (json['calfCount'] ?? 0).toDouble(),
      userId: json['userId'] ?? '',
      paymentType: json['paymentType'] ?? '',
      buffaloCount: (json['buffaloCount'] ?? 0).toDouble(),
      numUnits: (json['numUnits'] ?? 0).toDouble(),
      withCpf: json['withCpf'] ?? false,
      unitCost: (json['unitCost'] ?? 0).toDouble(),
      id: json['id'] ?? '',
      placedAt: DateTime.parse(json['placedAt'] ?? DateTime.now().toIso8601String()),
      cpfUnitCost: (json['cpfUnitCost'] ?? 0).toDouble(),
      paymentStatus: json['paymentStatus'] ?? '',
      totalCost: (json['totalCost'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'baseUnitCost': baseUnitCost,
      'paymentMode': paymentMode,
      'breedId': breedId,
      'calfCount': calfCount,
      'userId': userId,
      'paymentType': paymentType,
      'buffaloCount': buffaloCount,
      'numUnits': numUnits,
      'withCpf': withCpf,
      'unitCost': unitCost,
      'id': id,
      'placedAt': placedAt.toIso8601String(),
      'cpfUnitCost': cpfUnitCost,
      'paymentStatus': paymentStatus,
      'totalCost': totalCost,
    };
  }
}
