import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:animal_kart_demo2/l10n/app_localizations.dart';

class PaymentPendingScreen extends StatefulWidget {
  final String orderId;
  const PaymentPendingScreen({super.key, required this.orderId});

  @override
  State<PaymentPendingScreen> createState() => _PaymentPendingScreenState();
}

class _PaymentPendingScreenState extends State<PaymentPendingScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: Column(
        children: [
          const Spacer(),

          Container(
            height: 120,
            width: 120,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: kPrimaryGreen,
            ),
            child: const Icon(Icons.check, color: Colors.white, size: 70),
          ),

          const SizedBox(height: 25),
          Text(
            context.tr("paymentPending"),
            textAlign: TextAlign.center,
            style: tsFont22700.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Text(
            "Order ID: ${widget.orderId}",
            textAlign: TextAlign.center,
            style: tsFont16700.copyWith(
              fontWeight: FontWeight.bold,
              color: kTextPrimary,
            ),
          ),

          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              context.tr("paymentPendingDescription"),
              textAlign: TextAlign.center,
              style: tsFont14400.copyWith(color: kTextSecondary),
            ),
          ),

          const Spacer(),
          const Spacer(),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(20),
        child: SizedBox(
          height: 55,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: kPrimaryGreen,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
            onPressed: () {
              Navigator.pushReplacementNamed(
                context,
                AppRouter.home,
                arguments: 1,
              );
            },
            child: Text(
              context.tr("backToOrders"),
              style: tsFont18700.copyWith(
                fontWeight: FontWeight.w600,
                color: kWhite,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
