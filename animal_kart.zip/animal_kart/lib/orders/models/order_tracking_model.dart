class OrderTrackingResponse {
  final int statuscode;
  final String status;
  final String orderId;
  final String currentStatus;
  final String paymentStatus;
  final List<TimelineStage> timeline;

  OrderTrackingResponse({
    required this.statuscode,
    required this.status,
    required this.orderId,
    required this.currentStatus,
    required this.paymentStatus,
    required this.timeline,
  });

  factory OrderTrackingResponse.fromJson(Map<String, dynamic> json) {
    return OrderTrackingResponse(
      statuscode: json['statuscode'] ?? 0,
      status: json['status'] ?? '',
      orderId: json['orderId'] ?? '',
      currentStatus: json['currentStatus'] ?? '',
      paymentStatus: json['paymentStatus'] ?? '',
      timeline: (json['timeline'] as List? ?? [])
          .map((e) => TimelineStage.fromJson(e))
          .toList(),
    );
  }
}

class TimelineStage {
  final String stage;
  final String status;
  final String timestamp;
  final String description;

  TimelineStage({
    required this.stage,
    required this.status,
    required this.timestamp,
    required this.description,
  });

  factory TimelineStage.fromJson(Map<String, dynamic> json) {
    return TimelineStage(
      stage: json['stage'] ?? '',
      status: json['status'] ?? '',
      timestamp: json['timestamp'] ?? '',
      description: json['description'] ?? '',
    );
  }
}
