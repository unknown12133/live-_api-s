import 'package:flutter/material.dart';
import 'dart:ui_web' as ui_web;
import 'package:web/web.dart' as web;
import 'package:url_launcher/url_launcher.dart';
import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';

Widget createPdfView(String filePath) {
  final String viewType = 'pdf-view-${filePath.hashCode}';

  ui_web.platformViewRegistry.registerViewFactory(viewType, (int viewId) {
    final web.HTMLIFrameElement iframe = web.HTMLIFrameElement()
      ..src = filePath
      ..style.width = '100%'
      ..style.height = '100%'
      ..style.border = 'none';
    return iframe;
  });

  return HtmlElementView(viewType: viewType);
}

Future<void> downloadPdf(BuildContext context, String filePath) async {
  try {
    final uri = Uri.parse(filePath);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Could not launch $filePath';
    }
  } catch (e) {
    CustomSnackBar.show(
      context,
      title: 'Error',
      message: 'Error downloading PDF: $e',
      contentType: ContentType.failure,
    );
  }
}
