import 'package:animal_kart_demo2/l10n/app_localizations.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/orders/widgets/custom_widgets.dart';

import 'package:animal_kart_demo2/orders/widgets/dat_time_helper_widget.dart';
import 'package:animal_kart_demo2/orders/widgets/tracker_screen.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';

import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../../manualpayment/screens/manual_payment_screen.dart';

class BuffaloOrderCard extends StatelessWidget {
  final OrderUnit order;
  final Future<void> Function() onTapInvoice;
  final bool showInvoice;
  final bool showTrack;
  final bool showPayNow;

  const BuffaloOrderCard({
    super.key,
    required this.order,
    required this.onTapInvoice,
    required this.showInvoice,
    required this.showTrack,
    required this.showPayNow,
  });

  bool _isSmallScreen(BuildContext context) {
    return MediaQuery.of(context).size.width < 400;
  }

  @override
  Widget build(BuildContext context) {
    final String status = order.paymentStatus.toUpperCase();
    final bool isAdminVerificationPending =
        order.paymentStatus.toUpperCase() == "PENDING_ADMIN_VERIFICATION";
    final bool isPaid = status == "PAID";
    final bool isRejected = status == "REJECTED";

    final bool showPaymentType =
        (isPaid || isAdminVerificationPending || isRejected) &&
        order.paymentType != null;

    final bool isPendingPayment = status == "PENDING_PAYMENT";
    final bool isAdminReview = status == "PENDING_ADMIN_VERIFICATION";

    // Check for small screen to detect potential overflow (adjust threshold as needed)
    final bool isSmallScreen = MediaQuery.of(context).size.width < 400;

    String localizedPaymentType(BuildContext context, String paymentType) {
      switch (paymentType) {
        case "ONLINE_PAYMENT":
          return context.tr("onlinePayment");
        case "MANUAL_PAYMENT":
          return context.tr("manualPayment");
        case "CASH":
          return context.tr("cash");
        case "UPI":
          return context.tr("upi");
        case "BANK_TRANSFER":
          return context.tr("bankTransfer");
        case "CHEQUE":
          return context.tr("cheque");
        default:
          return paymentType.replaceAll("_", " ");
      }
    }

    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: isPendingPayment
          ? () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ManualPaymentScreen(
                    totalAmount: order.totalCost,
                    unitId: order.id,
                    userId: order.userId,
                    buffaloId: order.breedId,
                  ),
                ),
              );
            }
          : null,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .06),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "${context.tr("orderId")} : ${order.id}",
                        style: tsFont13900.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isPaid
                            ? "${context.tr("Approved On")} : ${formatToIndianDateTime(order.approvalDate ?? order.placedAt)}"
                            : "${context.tr("placedOn")} : ${formatToIndianDateTime(order.placedAt)}",
                        style: tsFont12700.copyWith(
                          fontWeight: FontWeight.w500,
                          color: kTextSecondary,
                        ),
                      ),

                      // Text(
                      //   "${context.tr("placedOn")} : ${formatToIndianDateTime(order.placedAt)}",
                      //   style: tsFont12700.copyWith(
                      //     fontWeight: FontWeight.w500,
                      //     color: kTextSecondary,
                      //   ),
                      // ),
                    ],
                  ),

                  if (isPaid) _statusChip(context.tr("paid"), Colors.green),

                  if (isPendingPayment)
                    _statusChip(context.tr("pending"), Colors.orange),

                  // Show Admin Review chip in top Row only if not small screen (no overflow)
                  if (isAdminReview && !isSmallScreen)
                    _statusChip(context.tr("adminReview"), const Color(0xFF7E57C2)),

                  if (isRejected)
                    _statusChip(context.tr("Rejected"), Colors.red),
                ],
              ),
            ),

            _divider(),

            /// ================= DETAILS =================
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment:
                    CrossAxisAlignment.start, // aligns everything at the top
                children: [
                  // ---------------- IMAGE ----------------
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      PngImage.femaleMurrah,
                      height: 70,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 10),

                  // ---------------- BUFFALO INFO ----------------
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "${context.tr("breedId")}: ${order.breedId}",
                          style: tsFont12700.copyWith(
                            fontWeight: FontWeight.w700,
                            fontSize: fs11,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Expanded(
                              child: Wrap(
                                alignment: WrapAlignment.start,
                                children: [
                                  _valueRow(
                                    context,
                                    "${order.buffaloCount}",
                                    order.buffaloCount == 1
                                        ? context.tr("buffalo")
                                        : context.tr("buffaloes"),
                                  ),
                                  const SizedBox(width: 2),
                                  _valueRow(
                                    context,
                                    "${order.calfCount}",
                                    order.calfCount == 1
                                        ? context.tr("calf")
                                        : context.tr("calves"),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          "${order.numUnits.toInt()} ${order.numUnits <= 1.5 ? context.tr("unit") : context.tr("units")}",
                          style: tsFont12700.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        
                        // Coins Redeemed Information
                       
                      ],
                    ),
                  ),

                  // ---------------- VERTICAL DIVIDER ----------------
                  Container(
                    height: 70, // match image or content height
                    width: 1,
                    color: Colors.grey.withValues(alpha: 0.5),
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                  ),

                  // ---------------- TOTAL COLUMN ----------------
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        context.tr("total"),
                        style: tsFont16700.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      // const SizedBox(height: 4),
                      Text(
                        FormatUtils.formatAmountWithCurrency(order.totalCost),
                        style: tsFont17900.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            _divider(),

            /// ================= BOTTOM SECTION =================
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// BUTTONS
                                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      /// PAY → ONLY PENDING PAYMENT
                      if (isPendingPayment && showPayNow)
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ManualPaymentScreen(
                                    totalAmount: order.totalCost,
                                    unitId: order.id,
                                    userId: order.userId,
                                    buffaloId: order.breedId,
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              margin: const EdgeInsets.only(left: 8),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.redAccent,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Center(
                                child: Text(
                                  context.tr("payNow"),
                                  style: tsFont12700.copyWith(
                                    color: kWhite,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),

                      // Always show payment type chip if paymentType is not null (for all orders), but skip if it's already shown in the bottom row for small screen admin review
                      if (order.paymentType != null && !(isAdminReview && isSmallScreen)) ...[
                        if (isPaid && showTrack)
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => TrackerScreen(
                                    orderId: order.id,
                                    buffaloType: order.breedId,
                                    unitCount: order.numUnits.toDouble(),
                                    purchaseDate: order.approvalDate.toString(),
                                    buffaloCount: order.buffaloCount.toDouble(),
                                    calfCount: order.calfCount.toDouble(),
                                    totalUnitcost: order.totalCost,
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              margin: const EdgeInsets.only(left: 8),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                context.tr("track"),
                                style: tsFont12700.copyWith(
                                  color: kWhite,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),

                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: isPaid ? Colors.green : Colors.green,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            localizedPaymentType(context, order.paymentType!),
                            style: tsFont11700.copyWith(
                              color: kWhite,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),

                        
                        if (!isPaid && order.coinsRedeemed != null && order.coinsRedeemed! > 0 && !_isSmallScreen(context))
                          Container(
                            margin: const EdgeInsets.only(left: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                              Text(
                                  "Redeemed:",
                                  style: tsFont11700.copyWith(
                                    fontWeight: FontWeight.w700,
                                    color: Colors.orange.shade800,
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  "${order.coinsRedeemed!.toInt()}",
                                  style: tsFont11700.copyWith(
                                    fontWeight: FontWeight.w700,
                                    color: Colors.orange.shade800,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (isPaid && showInvoice)
                          GestureDetector(
                            onTap: onTapInvoice,
                            child: Container(
                              margin: const EdgeInsets.only(left: 8),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                context.tr("invoice"),
                                style: tsFont12700.copyWith(
                                  color: kWhite,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ],
                  ),

                  const SizedBox(height: 6),

                  // Show Admin Review chip in bottom Row only if small screen (potential overflow)
                  if (isAdminReview && isSmallScreen)
                   Wrap(
                    
 // mainAxisAlignment: MainAxisAlignment.end,
  children: [
    _statusChip(
      context.tr("adminReview"),
      const Color(0xFF7E57C2),
    ),

    const SizedBox(width: 4), 

    /// COINS REDEEMED - Beside admin review on small screens
    if (!isPaid && order.coinsRedeemed != null && order.coinsRedeemed! > 0)
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.orange.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Redeemed:",
              style: tsFont11700.copyWith(
                fontWeight: FontWeight.w700,
                color: Colors.orange.shade800,
              ),
            ),
            const SizedBox(width: 2),
            Text(
              "${order.coinsRedeemed!.toInt()}",
              style: tsFont11700.copyWith(
                fontWeight: FontWeight.w700,
                color: Colors.orange.shade800,
              ),
            ),
          ],
        ),
      ),
const SizedBox(width: 4),
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.green,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        localizedPaymentType(context, order.paymentType!),
        style: tsFont11700.copyWith(
          color: kWhite,
          fontWeight: FontWeight.w700,
        ),
      ),
    ),
  ],
),


                  if (isAdminReview && isSmallScreen) const SizedBox(height: 6),

                  /// INFO MESSAGE
                  if (isPendingPayment || isAdminReview || isRejected)
                    Row(
                      children: [
                        const Icon(
                          Icons.info_outline,
                          size: 16,
                          color: Colors.grey,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            isPendingPayment
                                ? context.tr("bankDetailsNext")
                                : isAdminReview
                                ? context.tr("orderUnderReview")
                                : context.tr("rejectedMessage"),

                            style: tsFont12700.copyWith(
                              fontWeight: FontWeight.w700,
                              color: kTextSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// ================= HELPERS =================

  Widget _statusChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: tsFont11700.copyWith(color: kWhite, fontWeight: FontWeight.w700),
      ),
    );
  }

  Widget _divider() {
    return Container(
      height: 1,
      width: double.infinity,
      color: Colors.grey.withValues(alpha: 0.4),
    );
  }

  Widget _valueRow(BuildContext context, String value, String label) {
    return Text(
      "$value $label",
      style: tsFont12700.copyWith(fontWeight: FontWeight.w700),
    );
  }
}
