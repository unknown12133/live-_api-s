import 'package:animal_kart_demo2/l10n/app_localizations.dart';

import 'package:animal_kart_demo2/orders/models/order_tracking_model.dart';
import 'package:animal_kart_demo2/orders/providers/orders_providers.dart';
import 'package:animal_kart_demo2/orders/widgets/custom_widgets.dart';
import 'package:animal_kart_demo2/orders/widgets/dat_time_helper_widget.dart';
import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/utils/png_images.dart';
import 'package:animal_kart_demo2/widgets/Shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class TrackerScreen extends ConsumerStatefulWidget {
  final String orderId;
  final String buffaloType;
  final double unitCount;
  final String purchaseDate;
  final double buffaloCount;
  final double calfCount;
  final double totalUnitcost;

  const TrackerScreen({
    super.key,
    required this.orderId,
    required this.buffaloType,
    required this.unitCount,
    required this.purchaseDate,
    required this.buffaloCount,
    required this.calfCount,
    required this.totalUnitcost,
  });

  @override
  ConsumerState<TrackerScreen> createState() => _TrackerScreenState();
}

class _TrackerScreenState extends ConsumerState<TrackerScreen> {
  @override
  Widget build(BuildContext context) {
    final trackingAsync = ref.watch(orderTrackingProvider(widget.orderId));

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: kPrimaryGreen,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Track Order',
          style: TextStyle(
            color: Colors.white, 
            fontSize: 18, 
            fontWeight: FontWeight.w600,
            ),
        ),
       // centerTitle: true,
      ),
      // appBar: AppBar(
      //   backgroundColor: kWhite,
      //   elevation: 0,
      //   leading: IconButton(
      //     icon: const Icon(Icons.arrow_back_ios, color: kBlack),
      //     onPressed: () => Navigator.pop(context),
      //   ),
      //   title: Text('Track Order', style: tsFont20700_Gotham),
      // ),
      body: RefreshIndicator(
        onRefresh: () async {
          // Invalidate the provider to trigger a refresh
          return ref.refresh(orderTrackingProvider(widget.orderId).future);
        },
        color: kPrimaryColor,
        child: trackingAsync.when(
          data: (data) {
            if (data == null) {
              return _buildErrorState("Failed to load tracking details");
            }
            return SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  _buildHeader(),
                  const SizedBox(height: 20),
                  _buildTimeline(data),
                ],
              ),
            );
          },
          loading: () => _buildShimmer(),
          error: (error, stack) => _buildErrorState("Error: $error"),
        ),
      ),
    );
  }

  Widget _buildErrorState(String message) {
    return ListView(
      children: [
        SizedBox(height: MediaQuery.of(context).size.height * 0.3),
        Center(
          child: Text(
            message, 
            style: const TextStyle(color: Colors.red), 
            textAlign: TextAlign.center,
            ),
            ),
      ],
    );
  }

  Widget _buildShimmer() {
    return SingleChildScrollView(
      child: Column(
        children: [
          // Header Shimmer
        Container(
          height: 120,
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
          child: Row(
            children: [
                const CommonShimmer(
                  height: 60,
                  width: 80,
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, 
                mainAxisAlignment: MainAxisAlignment.center,
                children: 
                const [
                CommonShimmer(height: 14, width: 100),
                SizedBox(height: 8),
                CommonShimmer(height: 14, width: 150),
                SizedBox(height: 8),
                CommonShimmer(height: 14, width: 80),
                ],
              ),
            ),
          ],
        ),
      ),
        const SizedBox(height: 20),
          // Timeline Shimmer
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CommonShimmer(height: 24, width: 150), // Title
            const SizedBox(height: 24),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 4,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 32),
                  child: Row(
                    children: 
                    const [
                    CommonShimmer(
                      height: 40, 
                      width: 40, 
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                      ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        CommonShimmer(height: 16, width: 200),
                        SizedBox(height: 8),
                        CommonShimmer(height: 14, width: 100),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    final width = MediaQuery.of(context).size.width;
    double scale = (width / 390).clamp(0.80, 1.0);

    final double imgH = 70 * scale;
    final double imgW = 100 * scale;
    final double lineSize = 12 * scale;
    final double labelSize = 12 * scale;
    final double totalSize = 18 * scale;

    return Container(
      constraints: const BoxConstraints(minHeight: 95, maxHeight: 115),
      padding: EdgeInsets.symmetric(horizontal: 10 * scale),
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: kPrimaryDarkColor, width: 1),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(5 * scale),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10 * scale),
            child: Image.asset(
              PngImage.femaleMurrah, 
              height: imgH, 
              width: imgW, 
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(width: 5 * scale),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, 
              mainAxisAlignment: MainAxisAlignment.center, 
              children: [
              Text(
                "Breed ID:", 
                style: TextStyle(
                  fontSize: labelSize, 
                  fontWeight: FontWeight.w700,
                  ),
                  ),
              Text(widget.buffaloType, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: lineSize, fontWeight: FontWeight.w600)),
              SizedBox(height: 2 * scale),
              Wrap(
                spacing: 6 * scale,
                runSpacing: 3,
                children: [
                  _valueRow(
                    context,
                      widget.buffaloCount % 1 == 0 
                      ? widget.buffaloCount.toInt().toString() 
                      : widget.buffaloCount.toString(),
                      widget.buffaloCount == 1 
                      ? context.tr("buffalo") 
                      : context.tr("buffaloes"),
                      fontSize: lineSize,
                      ),
                  _valueRow(
                    context,
                      widget.calfCount % 1 == 0 
                      ? widget.calfCount.toInt().toString() 
                      : widget.calfCount.toString(),
                      widget.calfCount == 1 
                      ? context.tr("calf") 
                      : context.tr("calves"),
                      fontSize: lineSize
                      ),
                ],
              ),
              SizedBox(height: 2 * scale),
              Text("${widget.unitCount % 1 == 0 ? widget.unitCount.toInt().toString() : widget.unitCount.toString()} "
                  "${widget.unitCount == 1 ? context.tr("unit") : context.tr("units")}",
                  style: TextStyle(
                    fontSize: lineSize, 
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: imgH, 
            width: 1,
             color: Colors.grey.withOpacity(0.5), 
             margin: EdgeInsets.symmetric(horizontal: 8 * scale)
            ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center, 
            crossAxisAlignment: CrossAxisAlignment.start, 
            children: [
            Text(
              "Total", 
              style: TextStyle(fontSize: 14 * scale, fontWeight: FontWeight.w600),
              ),
            Text(
              FormatUtils.formatAmountWithCurrency(widget.totalUnitcost), 
              style: TextStyle(
                fontSize: totalSize, 
                fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeline(OrderTrackingResponse data) {
    final timeline = data.timeline;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white, 
        borderRadius: BorderRadius.circular(14), 
        boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.06), 
          blurRadius: 8, 
          offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, 
        children: [
        const Text(
          'Order Tracking', 
          style: TextStyle(
            fontSize: 20, 
            fontWeight: FontWeight.bold, 
            color: Colors.black,
            ),
            ),
        Text(
          "Order ID: ${widget.orderId}", 
          style: const TextStyle(
            fontSize: 12,           
          fontWeight: FontWeight.w700,
          ),
          ),
        const SizedBox(height: 24),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: timeline.length,
          itemBuilder: (context, index) {
              return _buildTimelineStep(
                timeline[index],
                index,
                timeline.length,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTimelineStep(TimelineStage stage, int index, int totalCount) {
    final bool isCompleted = stage.status == "COMPLETED";
    final bool isLast = index == totalCount - 1;

    // Parse timestamp
    DateTime? date;
    try {
      date = DateTime.parse(stage.timestamp);
    } catch (_) {}

    final dateStr = formatToIndianDateTime(date);

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Indicator column
          Column(
            children: [
              // Dot indicator
          Container(
            width: 40,
            height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isCompleted ? kPrimaryDarkColor : Colors.grey[300],
                ),
                child: Icon(
                  _getIconForStage(stage.stage),
                  size: 20,
                  color: isCompleted ? Colors.white : Colors.grey[400],
                ),
          ),
              // Connector line
          if (!isLast)
            Expanded(
                  child: Container(
                    width: 2.5,
                    color: isCompleted && (index < totalCount - 1)
                        ? kPrimaryDarkColor
                        : Colors.grey[300],
                      ),
                    ),
                 ],
                ),
              const SizedBox(width: 16),
          // Content column
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(bottom: isLast ? 0 : 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    stage.description.isNotEmpty
                        ? stage.description
                        : stage.stage.replaceAll("_", " "),
                  style: TextStyle(
                    fontSize: 15, 
                    fontWeight: FontWeight.w600, 
                    color: isCompleted ? Colors.black : Colors.grey[400],
                    ),
                  ),
              const SizedBox(height: 2),
              Text(
                dateStr, 
                style: TextStyle(
                  fontSize: 13, 
                  fontWeight: FontWeight.w600,
                      color: isCompleted ? Colors.black87 : Colors.grey[400],
                    ),
                  ),
                ],
            ),
          ),
        ),
        ],
      ),
    );
  }

  IconData _getIconForStage(String stage) {
    switch (stage) {
      case "ORDER_PLACED":
        return Icons.shopping_cart;
      case "PAYMENT_SUBMITTED":
        return Icons.payment;
      case "PAYMENT_VERIFIED":
        return Icons.verified;
      case "ORDER_APPROVED":
        return Icons.check_circle;
      case "BUFFALOS_BOUGHT":
        return Icons.pets;
      default:
        return Icons.circle;
    }
  }

  Widget _valueRow(BuildContext context, String value, String label, {double fontSize = 12}) {
    return Text(
      "$value $label", 
      style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.w600),
      );
  }
}