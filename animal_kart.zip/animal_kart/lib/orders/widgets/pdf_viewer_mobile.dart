import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:path/path.dart' as path;
import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';
import 'package:animal_kart_demo2/utils/app_colors.dart';

Widget createPdfView(String filePath) {
  return PDFView(
    filePath: filePath,
    enableSwipe: true,
    swipeHorizontal: true,
    autoSpacing: false,
    pageFling: true,
  );
}

Future<void> downloadPdf(BuildContext context, String filePath) async {
  try {
    final params = SaveFileDialogParams(
      sourceFilePath: filePath,
      fileName: path.basename(filePath),
    );

    final savedFilePath = await FlutterFileDialog.saveFile(params: params);

    if (savedFilePath != null) {
      CustomSnackBar.show(
        context,
        title: 'Success',
        message: 'PDF saved to: $savedFilePath',
        contentType: ContentType.success,
        color: kPrimaryGreen,
      );
    } else {
      CustomSnackBar.show(
        context,
        title: 'Info',
        message: 'PDF save canceled',
        contentType: ContentType.help,
      );
    }
  } catch (e) {
    CustomSnackBar.show(
      context,
      title: 'Error',
      message: 'Error saving PDF: $e',
      contentType: ContentType.failure,
    );
  }
}
