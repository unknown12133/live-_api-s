import 'package:flutter/material.dart';
import 'pdf_viewer_mobile.dart'
    if (dart.library.js_util) 'pdf_viewer_web.dart'
    if (dart.library.html) 'pdf_viewer_web.dart'
    as platform_impl;

class PdfViewWidget extends StatelessWidget {
  final String filePath;

  const PdfViewWidget({super.key, required this.filePath});

  @override
  Widget build(BuildContext context) {
    return platform_impl.createPdfView(filePath);
  }
}

Future<void> downloadPdfPlatform(BuildContext context, String filePath) async {
  await platform_impl.downloadPdf(context, filePath);
}
