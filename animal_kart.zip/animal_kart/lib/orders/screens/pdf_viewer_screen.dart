import 'package:flutter/material.dart';
import '../widgets/pdf_viewer_platform.dart';

class PdfViewerScreen extends StatelessWidget {
  final String filePath;

  const PdfViewerScreen({super.key, required this.filePath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Invoice"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () => downloadPdfPlatform(context, filePath),
          ),
        ],
      ),
      body: PdfViewWidget(filePath: filePath),
    );
  }
}
