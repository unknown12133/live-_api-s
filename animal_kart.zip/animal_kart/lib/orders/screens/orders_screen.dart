import 'package:animal_kart_demo2/utils/custom_snackbar_utils.dart';
import 'package:animal_kart_demo2/orders/models/order_model.dart';
import 'package:animal_kart_demo2/orders/providers/orders_providers.dart';
import 'package:animal_kart_demo2/orders/screens/invoice_screen.dart';
import 'package:animal_kart_demo2/orders/screens/pdf_viewer_screen.dart';
import 'package:animal_kart_demo2/orders/widgets/emptystate_widget.dart';
import 'package:animal_kart_demo2/orders/widgets/orders_card_widget.dart';

import 'package:animal_kart_demo2/theme/app_theme.dart';
import 'package:animal_kart_demo2/widgets/Shimmer_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:animal_kart_demo2/profile/providers/profile_provider.dart';
import 'package:animal_kart_demo2/auth/providers/auth_provider.dart';
import 'package:animal_kart_demo2/services/secure_storage_service.dart';
import 'package:animal_kart_demo2/routes/routes.dart';

final filterStateProvider = StateProvider<FilterState>((ref) {
  return FilterState();
});
final sortProvider = StateProvider<bool>((ref) => false);

class FilterState {
  String? statusFilter;
  bool sortByLatest = true;

  FilterState({this.statusFilter, this.sortByLatest = true});

  FilterState copyWith({
    String? statusFilter,
    // bool? sortByLatest,
    bool clearStatusFilter = false,
  }) {
    return FilterState(
      statusFilter: clearStatusFilter
          ? null
          : (statusFilter ?? this.statusFilter),
      // sortByLatest: sortByLatest ?? this.sortByLatest,
    );
  }
}

class OrdersScreen extends ConsumerStatefulWidget {
  const OrdersScreen({super.key});

  @override
  ConsumerState<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends ConsumerState<OrdersScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadOrders();
      // Also fetch profile to update isActive status
      ref.read(profileProvider.notifier).fetchCurrentUser();
    });
  }
  // void openFilterBottomSheet(BuildContext context) {
  //   showModalBottomSheet(
  //     context: context,
  //     backgroundColor: Colors.transparent,
  //     isScrollControlled: true,
  //     builder: (_) => const OrdersFilterBottomSheet(),
  //   );
  // }

  Future<void> _loadOrders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString('userMobile');

      await ref.read(ordersProvider.notifier).loadOrders(userId: userId!);

      // ✅ Refresh profile to update isAbleToRefer status if a purchase was made
      if (mounted) {
        ref.read(profileProvider.notifier).fetchCurrentUser();
      }
    } catch (error) {
      if (mounted) {
        CustomSnackBar.show(
          context,
          title: 'Error',
          message: 'Failed to load orders: $error',
          contentType: ContentType.failure,
        );
      }
    }
  }

  Widget _buildFilterChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
    required Color color,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? color : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? color : Colors.grey.shade300,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey.shade700,
            fontSize: 14,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Future<void> _performLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    await SecureStorageService.enableBiometric(false);
    ref.read(authProvider.notifier).clearSession();
    if (context.mounted) {
      Navigator.pushNamedAndRemoveUntil(
        context,
        AppRouter.login,
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final orders = ref.watch(ordersProvider);
    final isLoading = ref.watch(ordersLoadingProvider);
    final filterState = ref.watch(filterStateProvider);

    // Apply filters and sorting
    List<OrderUnit> filteredOrders = orders.where((order) {
      if (filterState.statusFilter == null) return true;
      return order.paymentStatus.toUpperCase() == filterState.statusFilter;
    }).toList();

    // Apply sorting
    filteredOrders.sort((a, b) {
      if (filterState.sortByLatest) {
        return b.placedAt.compareTo(a.placedAt);
      } else {
        return a.placedAt.compareTo(b.placedAt);
      }
    });

    final hasActiveFilters =
        filterState.statusFilter != null || !filterState.sortByLatest;

    return Scaffold(
      backgroundColor: kScreenBg,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _loadOrders,
          color: kPrimaryGreen,
          child: Column(
            children: [
              // Filter Chips at Top
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Filter Chips Row
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildFilterChip(
                            label: 'All',
                            isSelected: filterState.statusFilter == null,
                            onTap: () {
                              ref.read(filterStateProvider.notifier).state =
                                  filterState.copyWith(clearStatusFilter: true);
                            },
                            color: kPrimaryColor,
                          ),
                          const SizedBox(width: 8),
                          _buildFilterChip(
                            label: 'Paid',
                            isSelected: filterState.statusFilter == 'PAID',
                            onTap: () {
                              ref.read(filterStateProvider.notifier).state =
                                  filterState.copyWith(statusFilter: 'PAID');
                            },
                            color: Colors.green,
                          ),
                          const SizedBox(width: 8),
                          _buildFilterChip(
                            label: 'Pending',
                            isSelected:
                                filterState.statusFilter == 'PENDING_PAYMENT',
                            onTap: () {
                              ref
                                  .read(filterStateProvider.notifier)
                                  .state = filterState.copyWith(
                                statusFilter: 'PENDING_PAYMENT',
                              );
                            },
                            color: Colors.orange,
                          ),
                          const SizedBox(width: 8),
                          _buildFilterChip(
                            label: 'Admin Review',
                            isSelected:
                                filterState.statusFilter ==
                                'PENDING_ADMIN_VERIFICATION',
                            onTap: () {
                              ref
                                  .read(filterStateProvider.notifier)
                                  .state = filterState.copyWith(
                                statusFilter: 'PENDING_ADMIN_VERIFICATION',
                              );
                            },
                            color: const Color(0xFF7E57C2),
                          ),
                          const SizedBox(width: 8),
                          _buildFilterChip(
                            label: 'Rejected',
                            isSelected: filterState.statusFilter == 'REJECTED',
                            onTap: () {
                              ref
                                  .read(filterStateProvider.notifier)
                                  .state = filterState.copyWith(
                                statusFilter: 'REJECTED',
                              );
                            },
                            color: Colors.red,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),

              Expanded(
                child: isLoading
                    ? ordersShimmerList()
                    : filteredOrders.isEmpty
                    ? OrdersEmptyState(
                        noOrders: orders.isEmpty,
                        hasFilters: hasActiveFilters,
                      )
                    : Column(
                        children: [
                          // Orders Count
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              children: [
                                Text(
                                  '${filteredOrders.length} ${filteredOrders.length == 1 ? 'Order' : 'Orders'}',
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[600],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Orders List
                          Expanded(
                            child: ListView.builder(
                              padding: const EdgeInsets.only(
                                left: 16,
                                right: 16,
                                bottom: 16,
                              ),
                              itemCount: filteredOrders.length,
                              itemBuilder: (context, index) {
                                final order = filteredOrders[index];
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: BuffaloOrderCard(
                                    order: order,
                                    onTapInvoice: () async {
                                      final filePath =
                                          await InvoiceGenerator.generateInvoice(
                                            order,
                                          );
                                      if (context.mounted) {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                PdfViewerScreen(
                                                  filePath: filePath,
                                                ),
                                          ),
                                        );
                                      }
                                    },
                                    showInvoice: true,
                                    showTrack: true,
                                    showPayNow: true,
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
