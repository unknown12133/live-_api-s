importScripts("https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyC0XUQqk51NGLazlnaGKsPAgjkNNbgZR-E",
  appId: "1:612299373064:web:32b53e0ae6b3f6cc0eefbd",
  messagingSenderId: "612299373064",
  projectId: "markwave-481315",
  authDomain: "markwave-481315.firebaseapp.com",
  storageBucket: "gs://markwave-481315.firebasestorage.app",
  measurementId: "G-DSCQ6QCFC6"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log("Received background message ", payload);
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: "/icons/Icon-192.png",
  };

  return self.registration.showNotification(
    notificationTitle,
    notificationOptions
  );
});
