window.flutterWebRenderer = "html";

{{flutter_js}}
{{flutter_build_config}}

_flutter.loader.load();
