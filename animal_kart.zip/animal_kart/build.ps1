<#
.SYNOPSIS
    Build automation script for Animal Kart Flutter project.

.DESCRIPTION
    This script automates common build tasks for the Flutter project, including
    getting dependencies, cleaning the build, and building for different targets
    (APK, Web, AppBundle).

.PARAMETER Target
    The build target or action to perform.
    Options: 'get', 'clean', 'apk', 'web', 'appbundle', 'ios'
    Default is 'get'.

.EXAMPLE
    .\build.ps1
    Runs 'flutter pub get'.

.EXAMPLE
    .\build.ps1 -Target apk
    Builds the Android APK.

.EXAMPLE
    .\build.ps1 -Target clean
    Cleans the build artifacts.
#>

param (
    [ValidateSet('get', 'clean', 'apk', 'web', 'appbundle', 'ios', 'deploy-web')]
    [string]$Target = 'get'
)

$ErrorActionPreference = 'Stop'

function Show-Header {
    param ([string]$Title)
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  $Title" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
}

function Run-Command {
    param ([string]$Command, [string]$StepName)
    Show-Header $StepName
    Write-Host "Executing: $Command" -ForegroundColor Gray
    Invoke-Expression $Command
}

try {
    switch ($Target) {
        'get' {
            Run-Command "flutter pub get" "Getting Dependencies"
        }
        'clean' {
            Run-Command "flutter clean" "Cleaning Build"
            Run-Command "flutter pub get" "Getting Dependencies (after clean)"
        }
        'apk' {
            Run-Command "flutter build apk --release" "Building Android APK"
        }
        'web' {
            Run-Command "flutter build web --release" "Building Web App"
        }
        'appbundle' {
            Run-Command "flutter build appbundle --release" "Building Android AppBundle"
        }
        'ios' {
            # Check if running on macOS for iOS build
            if ($IsWindows) {
                Write-Warning "iOS builds are not supported on Windows."
            } else {
                Run-Command "flutter build ios --release" "Building iOS App"
            }
        }
        'deploy-web' {
            Run-Command "flutter build web --release --base-href /app/" "Building Web App for Deployment"
            $DestDir = "../animal_kart_static_site/public/app"
            if (Test-Path $DestDir) {
                Remove-Item -Path $DestDir -Recurse -Force
            }
            New-Item -ItemType Directory -Force -Path $DestDir | Out-Null
            Copy-Item -Path "build/web/*" -Destination $DestDir -Recurse
            Write-Host "Deployed web build to $DestDir" -ForegroundColor Green
        }
    }
    
    Write-Host "`nBuild action '$Target' completed successfully!" -ForegroundColor Green
}
catch {
    Write-Error "Build failed: $_"
    exit 1
}
